"""
Wallets and signed transactions for the 13th Chamber chain.

Real Ed25519 signatures (via `cryptography`), real addresses, no placeholders.
Addresses are base58 of sha256(public key) prefixed with 'q'.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
from typing import Any, Dict, Optional, Tuple

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization

ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def b58encode(raw: bytes) -> str:
    n = int.from_bytes(raw, "big")
    out = ""
    while n:
        n, rem = divmod(n, 58)
        out = ALPHABET[rem] + out
    pad = 0
    for byte in raw:
        if byte:
            break
        pad += 1
    return "1" * pad + (out or "")


def canonical(obj: Dict[str, Any]) -> bytes:
    """Deterministic JSON used for signing and hashing."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()


def address_for(public_key: bytes) -> str:
    return "q" + b58encode(hashlib.sha256(public_key).digest()[:20])


class Wallet:
    """A signing key plus its address."""

    def __init__(self, seed: Optional[bytes] = None, name: str = "wallet"):
        self.name = name
        if seed is None:
            seed = os.urandom(32)
        self._key = Ed25519PrivateKey.from_private_bytes(seed)
        self.public_key: bytes = self._key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        self.address = address_for(self.public_key)

    # -- persistence -------------------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        seed = self._key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        return {
            "name": self.name,
            "address": self.address,
            "public_key": b58encode(self.public_key),
            "secret": b58encode(seed),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Wallet":
        seed = b58decode(data["secret"])
        w = cls(seed, data.get("name", "wallet"))
        if w.address != data.get("address"):
            raise ValueError("keyfile address does not match its key")
        return w

    def save(self, directory: str = "keys") -> str:
        os.makedirs(directory, exist_ok=True)
        path = os.path.join(directory, f"{self.name}.key.json")
        with open(path, "w") as fh:
            json.dump(self.to_dict(), fh, indent=2)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return path

    @classmethod
    def load(cls, name: str, directory: str = "keys") -> "Wallet":
        path = os.path.join(directory, f"{name}.key.json")
        with open(path) as fh:
            return cls.from_dict(json.load(fh))

    # -- signing -----------------------------------------------------------
    def sign(self, payload: Dict[str, Any]) -> str:
        return b58encode(self._key.sign(canonical(payload)))

    def make_tx(self, to: str, amount_units: int, fee_units: int,
                nonce: int, timestamp_ms: int, memo: str = "",
                tx_type: str = "transfer", asset: str = "qsam") -> Dict[str, Any]:
        body = {
            "v": 1,
            "type": tx_type,
            "asset": asset,
            "from": self.address,
            "to": to,
            "amount": int(amount_units),
            "fee": int(fee_units),
            "nonce": int(nonce),
            "timestamp": int(timestamp_ms),
            "memo": memo,
            "pubkey": b58encode(self.public_key),
        }
        body["signature"] = self.sign(body)
        return body


def b58decode(text: str) -> bytes:
    n = 0
    for char in text:
        n = n * 58 + ALPHABET.index(char)
    raw = n.to_bytes((n.bit_length() + 7) // 8, "big")
    pad = len(text) - len(text.lstrip("1"))
    return b"\x00" * pad + raw


def verify_tx(tx: Dict[str, Any]) -> Tuple[bool, str]:
    """Check a transaction's signature and its internal consistency."""
    required = ("from", "to", "amount", "fee", "nonce", "pubkey", "signature")
    for field in required:
        if field not in tx:
            return False, f"missing field {field}"

    if int(tx["amount"]) < 0 or int(tx["fee"]) < 0:
        return False, "negative amount or fee"

    try:
        pub_bytes = b58decode(tx["pubkey"])
        signature = b58decode(tx["signature"])
    except Exception:
        return False, "malformed encoding"

    if address_for(pub_bytes) != tx["from"]:
        return False, "address does not belong to the signing key"

    payload = {k: v for k, v in tx.items() if k != "signature"}
    try:
        Ed25519PublicKey.from_public_bytes(pub_bytes).verify(signature, canonical(payload))
    except InvalidSignature:
        return False, "bad signature"
    except Exception as exc:  # pragma: no cover
        return False, f"signature error: {exc}"
    return True, "ok"


def tx_hash(tx: Dict[str, Any]) -> str:
    return hashlib.sha256(canonical(tx)).hexdigest()
