"""
Peer-to-peer gossip for the 13th Chamber chain.

Design, deliberately boring
---------------------------
Transport is plain HTTP + JSON, so any node is inspectable with curl and there is
no binary protocol to debug. Peers are supplied on the command line or added at
runtime through POST /p2p/connect. There is no discovery service and no DHT:
a node knows the peers it was told about.

Flooding is deduplicated by block hash and transaction hash, so a message that
comes back around the ring is dropped instead of re-broadcast. Fork choice is by
cumulative quantum work, then height, then hash, which makes convergence
deterministic: two nodes that see the same set of blocks always agree on the tip.

Security note
-------------
There is no authentication, encryption or rate limiting here. Run it on a trusted
network, or behind a reverse proxy that terminates TLS and authenticates. Do not
put this port on the open internet as-is.
"""

from __future__ import annotations

import json
import threading
import time
from typing import Any, Dict, List, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

SEEN_TTL = 120.0          # seconds to remember a hash for dedupe
MAX_PEERS = 64            # hard cap so a hostile origin header cannot flood us


def normalise(addr: str) -> str:
    """Accept 'host:port', 'http://host:port/' and return 'host:port'."""
    addr = (addr or "").strip()
    for prefix in ("http://", "https://"):
        if addr.startswith(prefix):
            addr = addr[len(prefix):]
    return addr.rstrip("/")


class PeerPool:
    def __init__(self, chain, self_addr: str = "", timeout: float = 6.0,
                 sync_interval: float = 2.0):
        self.chain = chain
        self.self_addr = normalise(self_addr)
        self.timeout = timeout
        self.sync_interval = sync_interval
        self.peers: List[str] = []
        self.stats: Dict[str, int] = {
            "blocks_in": 0, "blocks_out": 0, "tx_in": 0, "tx_out": 0,
            "reorgs": 0, "rejected_in": 0, "syncs": 0, "peer_errors": 0,
        }
        self.log: List[str] = []
        self._seen_blocks: Dict[str, float] = {}
        self._seen_txs: Dict[str, float] = {}
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------------ log
    def note(self, message: str) -> None:
        stamp = time.strftime("%H:%M:%S")
        with self._lock:
            self.log.append(f"{stamp} {message}")
            if len(self.log) > 400:
                del self.log[:-400]

    # ------------------------------------------------------------- http bits
    def _url(self, addr: str, path: str) -> str:
        return f"http://{normalise(addr)}{path}"

    def _get(self, addr: str, path: str) -> Optional[Any]:
        headers = {"Accept": "application/json"}
        if self.self_addr:
            headers["X-Node-Addr"] = self.self_addr
        try:
            with urlopen(Request(self._url(addr, path), headers=headers),
                         timeout=self.timeout) as resp:
                return json.loads(resp.read() or b"null")
        except (URLError, HTTPError, json.JSONDecodeError, OSError) as exc:
            self.stats["peer_errors"] += 1
            self.note(f"GET {addr}{path} failed: {type(exc).__name__}")
            return None

    def _post(self, addr: str, path: str, payload: Any) -> Optional[Any]:
        body = json.dumps(payload).encode()
        headers = {"Content-Type": "application/json"}
        if self.self_addr:
            headers["X-Node-Addr"] = self.self_addr
        try:
            req = Request(self._url(addr, path), data=body, headers=headers)
            with urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read() or b"null")
        except HTTPError as exc:
            # a 400 is a real answer from the peer, not a transport failure
            try:
                return json.loads(exc.read() or b"null")
            except Exception:
                self.stats["peer_errors"] += 1
                return {"error": f"http {exc.code}"}
        except (URLError, json.JSONDecodeError, OSError) as exc:
            self.stats["peer_errors"] += 1
            self.note(f"POST {addr}{path} failed: {type(exc).__name__}")
            return None

    # ---------------------------------------------------------------- peers
    def add_peer(self, addr: str) -> bool:
        addr = normalise(addr)
        if not addr or addr == self.self_addr:
            return False
        if ":" not in addr or any(c.isspace() for c in addr) or len(addr) > 64:
            return False                      # not a host:port, refuse to remember it
        with self._lock:
            if addr in self.peers or len(self.peers) >= MAX_PEERS:
                return False
            self.peers.append(addr)
            fresh = True
        if fresh:
            self.note(f"peer added {addr}")
        return True

    def learn_from(self, addr: str) -> int:
        """Peer exchange: ask a peer who else it knows and add the new ones."""
        res = self._get(addr, "/p2p/peers")
        if not isinstance(res, dict):
            return 0
        added = 0
        for other in res.get("peers", []):
            if self.add_peer(other):
                added += 1
        return added

    def remove_peer(self, addr: str) -> bool:
        addr = normalise(addr)
        with self._lock:
            if addr in self.peers:
                self.peers.remove(addr)
                return True
        return False

    def hello(self, addr: str) -> Optional[Dict[str, Any]]:
        return self._get(addr, "/p2p/hello")

    # ------------------------------------------------------------ messaging
    def _seen_block(self, block_hash: str) -> bool:
        now = time.time()
        with self._lock:
            self._seen_blocks = {h: t for h, t in self._seen_blocks.items()
                                 if now - t < SEEN_TTL}
            if block_hash in self._seen_blocks:
                return True
            self._seen_blocks[block_hash] = now
            return False

    def _seen_tx(self, tx_hash: str) -> bool:
        now = time.time()
        with self._lock:
            self._seen_txs = {h: t for h, t in self._seen_txs.items()
                              if now - t < SEEN_TTL}
            if tx_hash in self._seen_txs:
                return True
            self._seen_txs[tx_hash] = now
            return False

    def broadcast_block(self, block: Dict[str, Any], exclude: Optional[str] = None) -> None:
        if self._seen_block(block["hash"]):
            return
        for addr in list(self.peers):
            if exclude and normalise(exclude) == addr:
                continue
            res = self._post(addr, "/p2p/block", block)
            if isinstance(res, dict):
                self.stats["blocks_out"] += 1
                if res.get("status") in ("rejected", "orphan"):
                    self.note(f"{addr} -> {res.get('status')}: {res.get('detail')}")

    def broadcast_tx(self, tx: Dict[str, Any], exclude: Optional[str] = None) -> None:
        txh = self.chain_tx_hash(tx)
        if self._seen_tx(txh):
            return
        for addr in list(self.peers):
            if exclude and normalise(exclude) == addr:
                continue
            res = self._post(addr, "/p2p/tx", tx)
            if isinstance(res, dict) and res.get("accepted"):
                self.stats["tx_out"] += 1

    @staticmethod
    def chain_tx_hash(tx: Dict[str, Any]) -> str:
        from wallet import tx_hash
        return tx_hash(tx)

    # ----------------------------------------------------------------- sync
    def fetch_blocks(self, addr: str, from_height: int = 0) -> List[Dict[str, Any]]:
        res = self._get(addr, f"/p2p/blocks?from={int(from_height)}")
        return res if isinstance(res, list) else []

    def sync_from(self, addr: str, verbose: bool = False) -> int:
        """Pull any blocks we are missing. Returns how many we accepted."""
        theirs = self.hello(addr)
        if not isinstance(theirs, dict):
            return 0
        if theirs.get("chain_id") != self.chain.config["chain_id"]:
            self.note(f"{addr} is on chain {theirs.get('chain_id')} - ignoring")
            return 0

        mine = self.chain.tip_key()
        their_key = (float(theirs.get("work") or 0.0),
                     int(theirs.get("height") or -1),
                     str(theirs.get("head") or ""))
        if their_key <= mine:
            return 0

        accepted = 0
        start = max(0, self.chain.height() - 2) if self.chain.blocks else 0
        blocks = self.fetch_blocks(addr, start)
        orphaned = False
        for block in blocks:
            res = self.chain.receive_block(block)
            if res["status"] in ("appended", "reorg"):
                accepted += 1
                if res["status"] == "reorg":
                    self.stats["reorgs"] += 1
                    self.note(f"reorg onto {addr}: {res['detail']}")
            elif res["status"] == "orphan":
                orphaned = True
        if orphaned:  # deeper fork: pay for a full pull
            for block in self.fetch_blocks(addr, 0):
                res = self.chain.receive_block(block)
                if res["status"] in ("appended", "reorg"):
                    accepted += 1
        self.stats["syncs"] += 1
        if accepted:
            self.note(f"synced {accepted} block(s) from {addr} "
                      f"-> height {self.chain.height()}")
        return accepted

    def sync_all(self) -> int:
        total = 0
        for addr in list(self.peers):
            total += self.sync_from(addr)
            try:
                self.learn_from(addr)
            except Exception:
                pass
        return total

    # --------------------------------------------------------------- threads
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="p2p-sync", daemon=True)
        self._thread.start()
        self.note(f"gossip started, {len(self.peers)} peer(s), "
                  f"interval {self.sync_interval}s")

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.sync_all()
            except Exception as exc:                     # never kill the loop
                self.note(f"sync error: {type(exc).__name__}: {exc}")
            self._stop.wait(self.sync_interval)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3)

    # ---------------------------------------------------------------- stats
    def status(self) -> Dict[str, Any]:
        return {
            "self": self.self_addr,
            "peers": list(self.peers),
            "peer_count": len(self.peers),
            "stats": dict(self.stats),
            "log": self.log[-40:],
        }
