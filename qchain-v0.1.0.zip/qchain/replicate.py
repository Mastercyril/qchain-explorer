"""Process replication with hard guardrails.

A node can create child nodes. Membership, ports and parentage live in a
flock-protected registry so concurrent spawns cannot collide on a port.
Guardrails (max_nodes, max_depth, cooldown) are enforced in rules.allow_spawn
before anything here is called.
"""

from __future__ import annotations

import fcntl
import json
import os
import subprocess
import sys
import time
from typing import Any, Dict, List, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
KEYS = os.path.join(HERE, "keys")


class Registry:
    def __init__(self, root: str):
        self.path = os.path.join(root, "registry.json")
        os.makedirs(root, exist_ok=True)

    def _guarded(self, fn):
        lock = open(self.path + ".lock", "a+")
        try:
            fcntl.flock(lock, fcntl.LOCK_EX)
            return fn()
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)
            lock.close()

    def read(self) -> Dict[str, Any]:
        try:
            with open(self.path) as fh:
                return json.load(fh)
        except Exception:
            return {"nodes": []}

    def _write(self, data: Dict[str, Any]) -> None:
        tmp = self.path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(data, fh, indent=1)
        os.replace(tmp, self.path)

    def add(self, node: Dict[str, Any]) -> Dict[str, Any]:
        def op():
            data = self.read()
            data.setdefault("nodes", [])
            data["nodes"] = [n for n in data["nodes"] if n["port"] != node["port"]]
            data["nodes"].append(node)
            self._write(data)
            return data
        return self._guarded(op)

    def remove(self, port: int) -> Dict[str, Any]:
        def op():
            data = self.read()
            data["nodes"] = [n for n in data.get("nodes", []) if n["port"] != port]
            self._write(data)
            return data
        return self._guarded(op)

    def nodes(self) -> List[Dict[str, Any]]:
        return self.read().get("nodes", [])

    def count(self) -> int:
        return len(self.nodes())

    def ports(self) -> List[int]:
        return [int(n["port"]) for n in self.nodes()]

    def alloc_port(self, base: int) -> int:
        def op():
            data = self.read()
            used = {int(n["port"]) for n in data.get("nodes", [])}
            port = int(data.get("next_port") or base)
            while port in used:
                port += 1
            data["next_port"] = port + 1
            self._write(data)
            return port
        return self._guarded(op)


def spawn(root: str, name: str, port: int, peers: List[str], depth: int,
          policy: str, seed: str, parent_port: Optional[int] = None) -> subprocess.Popen:
    """Create the child's wallet, launch it, and record it in the registry."""
    from wallet import Wallet
    Wallet(name=name).save(KEYS)
    data = os.path.join(root, f"node-{port}")
    cmd = [sys.executable, "worker.py",
           "--name", name, "--data", data, "--port", str(port),
           "--key", name, "--policy", policy, "--depth", str(depth),
           "--root", root, "--seed", seed]
    for p in peers:
        cmd += ["--peer", p]
    log_dir = os.path.join(root, "logs")
    os.makedirs(log_dir, exist_ok=True)
    log = open(os.path.join(log_dir, f"{name}.log"), "w")
    proc = subprocess.Popen(cmd, cwd=HERE, stdout=log, stderr=subprocess.STDOUT)
    Registry(root).add({
        "name": name, "port": port, "depth": depth, "peers": peers,
        "pid": proc.pid, "parent_port": parent_port, "started": time.time(),
    })
    return proc
