# 13th Chamber Chain

A working Proof-of-Quantum-Work ledger for 13th Chamber LLC, carrying both of the
company's assets and running as a peer-to-peer network. This is the settlement and
compute layer described in `quantum-crypto-wp.md` section 6.1, implemented and
running, not a design document.

It settles QSAM and registers QBTC. It does not replace Solana. QSAM stays
tradeable on Solana (mint `48YZxAUXFcEG14kEWHyBBaEx1gabprkXxQsz2ViuPZPN`, mint and
freeze authority both revoked); this chain is where the quantum work gets proven
and where QBTC custody is recorded.

---

## Two assets, two different jobs

| | QSAM | QBTC |
|---|---|---|
| Fixed supply | 1,000,000,000 | 21,000,000 |
| Transferable | **yes** | **no, ever** |
| Purpose | the public, spendable asset | a register of custody |
| Enforced by | signatures, nonces, balances | mempool + block validation + audit |

QBTC moves exactly once: from the genesis transaction into the QBTC treasury. After
that it cannot move. Three independent layers refuse it, so "not for sale" is a
property of the ledger rather than a promise on a website:

```
[3] QBTC is non-transferable, enforced at three layers
    a) mempool admission:
    QBTC qbtc_treasury ->     100  QBTC is non-transferable (not for sale)
    b) block validation:
       block accepted? False  ->  tx 0: QBTC is non-transferable but was moved
    c) the full chain audit refuses to load such a block at all
```

`test_cannot_spend_qbtc_balance_as_qsam` covers the obvious dodge: holding 21M QBTC
gives you zero QSAM spending power.

---

## Peer to peer

Transport is plain HTTP + JSON, so every node is inspectable with curl and there is
no binary protocol to debug. A node is started with the peers it should talk to:

```bash
python3 node.py --data node1 --port 8080
python3 node.py --data node2 --port 8090 --peer 127.0.0.1:8080
```

The mesh then forms itself. Any node that contacts us becomes a peer, and every
sync round asks each peer who else it knows (`/p2p/peers`), so a node added at one
edge of the network becomes visible to the rest. Capped at 64 peers per node so a
hostile origin header cannot flood the list.

**Gossip.** Mined blocks and accepted transactions are flooded to all peers
immediately and deduplicated by hash, so a message that comes back around the ring
is dropped rather than re-broadcast.

**Fork choice** is by cumulative quantum work, then height, then hash:

```
candidate = (sum of amplification, height, hash)   highest wins
```

That makes convergence deterministic: two nodes holding the same blocks always
agree on the tip. A block that arrives for a branch we do not have is validated and
kept as a side branch. If its branch carries more work than ours, we reorg onto it
and put any orphaned transactions back in the mempool.

Measured on a live partition test, two nodes mining independently against the same
genesis:

```
P: height 1 work 30.8114x   Q: height 3 work 67.4956x
-> after reconnect: P abandons 30.8114x for 67.4956x (1 reorg), both at height 3
```

Work is randomized per run, so the exact figures differ each time (a later run put
the same test at 29.0919x versus 58.0131x). The ordering never does.

**Sync.** Each round, a node asks a peer for `/p2p/hello`; if the peer's tip key is
higher, it pulls blocks and feeds them through the same `receive_block` path used
for gossip. There is one code path for "block arrived" no matter where it came
from, which is why a synced node and a gossiped node end up identical.

### Network test results

`python3 p2p_test.py` starts real node processes on real ports and asserts:

```
PASS  new node adopts genesis over the wire          (from an empty data directory)
PASS  mined block reaches every peer                 (height 1, identical head on A, B, C)
PASS  transaction gossips to peers then confirms     (submitted on B, mined on C, in A's block 2)
PASS  peer refuses a block that moves QBTC           (rejected: QBTC is non-transferable)
PASS  peer refuses an inflated quantum claim         (rejected: concentration mismatch)
PASS  partitioned chains converge on more work       (P reorgs onto the heavier branch)
PASS  every node's chain still audits clean          (6 nodes, all valid)

7/7 network checks passed in 1.8s
```

---

## Proof-of-Quantum-Work, precisely

Each block's challenge is derived from the previous block hash, the transaction
Merkle root, the miner address, the timestamp and a nonce:

```
challenge = sha256("poqw|" + prev_hash|merkle_root|miner|timestamp|nonce)
```

The challenge is expanded into a 6-qubit parameterised circuit: 12 rotation gates
with 16-bit angle resolution and 12 entangling CNOT gates on a ring, two layers
deep. The circuit is prepared on |000000> and the output distribution is measured
over all 64 outcomes.

One outcome, the target, is chosen from the challenge. The work score is how much
probability that outcome carries compared with blind guessing:

```
baseline      = 1 / 64        = 1.5625%
concentration = P(target)
amplification = concentration / baseline        e.g. 19.03x
```

A block is valid only if its amplification clears the network threshold (default
**12.5x**, the consensus average published in whitepaper section 8.2) and its hash
meets the classical difficulty.

Measured on the shipped chain, `demo_data/chain.jsonl`:

| block | target | concentration | amplification | tx | nonces tried | mined | assets |
|-------|--------|---------------|---------------|----|--------------|-------|--------|
| 0 (genesis) | \|000010⟩ | 20.9916% | 13.43x | 2 | 1,609 | 301 ms | QBTC + QSAM |
| 1 | \|011110⟩ | 26.1579% | 16.74x | 4 | 7,786 | 1,443 ms | QSAM |
| 2 | \|100000⟩ | 29.7399% | 19.03x | 4 | 1,974 | 367 ms | QSAM |
| 3 | \|011110⟩ | 19.7796% | 12.66x | 4 | 6,774 | 1,309 ms | QSAM |

Mean amplification **15.47x**, cumulative chain work **61.8682x**, against a 1.5625%
random baseline.

**Why this is a proof and not a number.** The block stores the challenge, the target
outcome, the concentration and a fingerprint of the full 64-amplitude state. Every
validating node re-derives the challenge from the header, re-runs the same circuit
and must reproduce the same concentration to 1e-9. A miner cannot invent a good
score, and the network test proves a peer will refuse one that tries.

**Honest scope.** The simulator is a full statevector simulation, deterministic and
exact, but it runs on a CPU. It is not quantum hardware. Porting the same circuits
to IBM Quantum through Qiskit is the step that turns this into the whitepaper's
claim, and the circuit layer is deliberately isolated in `quantum.py` so that swap
stays contained.

---

## Economic rules

- **Fixed supply, twice over.** Genesis mints QSAM once and QBTC once. There is no
  mint path anywhere in the code and no block reward, so neither supply can grow.
  The audit asserts each asset's total equals its configured supply after every run.
- **Miners earn fees only**, paid in the asset they processed. Minimum fee 0.001.
- **Signed transactions.** Every transfer carries a real Ed25519 signature over a
  canonical JSON encoding that includes the asset, plus a per-sender nonce.
- **Rejected at three points:** mempool admission, block validation, full audit.
  Double spends, replays, bad nonces, low fees, forged signatures, unknown assets
  and any QBTC movement are all refused.

---

## Layout

```
quantum.py      statevector simulator, challenge derivation, PoQW work + verifier
wallet.py       Ed25519 keys, base58 addresses, canonical signing, tx verification
chain.py        asset registry, Merkle roots, mining, validation, fork choice, reorgs
p2p.py          peer pool, gossip, peer exchange, sync loop
node.py         HTTP node, explorer API and peer-to-peer endpoints
cli.py          init / wallet / send / mine / verify / status / tamper / demo / serve
explorer.html   the block explorer, including live network state
tests.py        46 unit tests
p2p_test.py     live multi-process network test

bot.py          a simple autonomous node (send + mine on a timer)
botnet.py       funds N wallets, spawns N bots, reports convergence
policy.json     the execution policy: ordered rules over observable facts
rules.py        deterministic rule engine (no randomness, fails closed)
worker.py       a node whose behaviour comes from policy.json
replicate.py    child spawning + a flock-protected registry and port allocator
swarm.py        starts ONE seed and lets the policy grow the network
work_export.py  exports per-block PoQW claims as TSV for the JVM verifier
kotlin/Poqw.kt        the same simulator in Kotlin, bit-for-bit
kotlin/VerifyChain.kt re-derives every block's quantum work on the JVM
```

Runtime dependencies: Python 3.9+ and `cryptography`. Nothing else.

## Commands

```bash
python3 cli.py demo                          # build a two-asset chain, exercise every rule
python3 cli.py init                          # genesis block (creates treasury key)
python3 cli.py wallet new alice              # a signing key
python3 cli.py wallets                       # keys with QSAM and QBTC balances
python3 cli.py send alice qXXX... 25         # queue a signed QSAM transfer
python3 cli.py send alice qXXX... 5 --asset qbtc   # refused: non-transferable
python3 cli.py mine treasury --blocks 3      # mine from the mempool
python3 cli.py verify                        # full audit
python3 cli.py status                        # chain summary as JSON
python3 cli.py tamper                        # proving tampering is caught
python3 cli.py serve --port 8080 --peer 127.0.0.1:8090   # node with a peer
python3 p2p_test.py                          # live network test
```

### HTTP API

```
GET  /                        block explorer
GET  /api/status              chain summary, both assets, live peer count
GET  /api/blocks?limit=40     recent blocks
GET  /api/block/{height|hash} full block, transactions tagged by asset, quantum claim
GET  /api/address/{addr}      QSAM and QBTC balances, nonce, history
GET  /api/mempool             pending transactions
GET  /api/verify              full audit
POST /api/tx                  submit a signed transaction (broadcasts)
POST /api/mine                mine a block (broadcasts)

GET  /p2p/hello               node id, height, head, cumulative work
GET  /p2p/blocks?from=N       blocks from a height, for sync
GET  /p2p/peers               this node's peer list
GET  /p2p/stats               counters and the recent gossip log
POST /p2p/block               offer a block
POST /p2p/tx                  offer a transaction
POST /p2p/connect             add a peer at runtime:  {"peer": "host:port"}
POST /p2p/disconnect          drop a peer
```

---

## Test results

```
46 unit tests          Ran 46 tests in 0.140s                 OK
7 network checks       7/7 network checks passed             PASS
JVM re-derivation      4 blocks verified, 0 mismatched       ok
swarm from one seed    4 nodes, 4/4 valid, 6/6 samples agreed
```

Unit coverage: simulator determinism, statevector normalisation, challenge
sensitivity, forged quantum claims, Merkle ordering, signature forgery, address
spoofing, double spends, bad nonces, fee floors, broken chain links, tampered
transactions, threshold enforcement, per-asset supply invariants, persistence,
QBTC rules at all three layers, fork-choice ordering, orphan and duplicate
handling, broken-hash and foreign-chain rejection.

---

## What is genuinely strong here

1. The quantum work is **reproducible and checkable by anyone**, and a peer refuses
   a block whose claimed work does not reproduce.
2. QBTC's "not for sale" status is **mechanically enforced**, not documented.
3. Fork choice on cumulative work gives **deterministic convergence**, demonstrated
   by a live partition-and-reconnect test.
4. Both supplies are audited to the unit on every run.
5. Tamper detection is live: change one amount in a confirmed block and both the
   Merkle root and the signature break.

## Kotlin verifier

The consensus layer is not tied to Python. `kotlin/Poqw.kt` independently implements
the same 6-qubit statevector simulator, challenge derivation and concentration
metric, and `kotlin/VerifyChain.kt` checks a whole chain with it.

```
python3 work_export.py demo_data/chain.jsonl work.tsv
kotlinc kotlin/Poqw.kt kotlin/VerifyChain.kt -include-runtime -d verify.jar
java -jar verify.jar work.tsv
```

Measured on the shipped chain:

```
height  target      concentration  amplification  fingerprint       verdict
1       |011110>    0.2615793482   16.7411x       7e6edc210012c8f0  ok
2       |100000>    0.2973993330   19.0336x       6ea5edc3f361d729  ok
3       |011110>    0.1977959502   12.6589x       1a0ab0bb0519453a  ok
blocks verified: 4   mismatched: 0
RESULT: every PoQW claim reproduced on the JVM
```

State fingerprints match the Python miner exactly, so a block's quantum work is
portable across implementations. Kotlin verifies; Python is still the node.

## Self-replicating network

A node's behaviour is data, not code. `policy.json` holds ordered rules over
observable facts, `rules.py` evaluates them deterministically, and guardrails cap
what can happen: `max_nodes 7`, `max_depth 1`, `spawn_cooldown_s 3`.

```
python3 swarm.py --duration 40      # start ONE seed, walk away
```

The seed reads its own policy, mines, funds wallets, and spawns children that
inherit the policy one depth down. Each child bootstraps from a single address and
finds the rest of the mesh through peer exchange. Funder, miner, peer and parent
are all decided by rules, so the growth is reproducible rather than improvised.

Measured from one seed:

```
nodes created by the policy, not the operator : 4
chains that audit clean                        : 4/4
heads during the run                           : 6/6 samples fully agreed
heads after quiescing                          : all identical
```

Under seven nodes mining concurrently you see transient competing heads; that is
correct behaviour, so the harness pauses every node before judging convergence.

---

## What is not built yet

- **No authentication, TLS or peer banning.** Gossip is open and unauthenticated.
  Run it on a trusted network or behind a proxy that terminates TLS. Do not expose
  the port to the open internet as-is.
- **Sync is O(chain).** A node pulls blocks and filters locally; there are no
  locator-style efficient catch-up, so very long chains will sync slowly.
- **No difficulty retarget** yet: threshold and difficulty are fixed in config.
- **Side branches live in memory only**, so a restart forgets losing branches.
- **The JVM side verifies PoQW only.** A full Kotlin node (mempool, gossip,
  mining) is not written; Python remains the node.
- **No light client or SPV proofs.**
- **No hardware quantum execution.** See the scope note above.
- **Not audited.** Do not custody other people's funds with this.
- Demo keys in `keys/` are throwaway. Never reuse them for anything holding value.

## Sensible next steps

1. **TLS + peer authentication** before this touches a public interface.
2. **IBM Quantum execution** behind the same interface, storing the IBM job ID in
   the block header.
3. **Difficulty retarget** driven by observed amplification, so blocks stay on a
   predictable schedule as the network grows.
4. **Block locators** for efficient sync instead of scanning the chain.
5. **Solana attestation**: commit a periodic Merkle root of this chain so its
   history is anchored on Solana and publicly checkable.
6. **Cold storage for the treasury key** `2iG3NGn2pcRabznaU1ndC17JcQqewERhQL53G3Z5Suff`,
   which currently holds 100% of on-chain QBTC and the 350M QSAM and still carries
   mint and freeze authority on both.

---

13th Chamber LLC · QSAM fixed supply, no mint authority · QBTC non-transferable, not for sale.

---

## Continuous verification on GitHub

`.github/workflows/qchain-ci.yml` runs the whole proof on every push: the unit
tests, a full audit of the shipped chain, the live peer-to-peer network test, then
a Kotlin build and a JVM re-derivation of every block's quantum work.

If the workflow is not active yet, it is because the token used to push lacked
GitHub's `workflow` scope. Move `ci/qchain-ci.yml` to `.github/workflows/` in the
web UI, or re-authorise with that scope, and it starts running on the next push.
