"""An autonomous node: serves the full API, gossips, and on its own schedule
signs transfers and mines blocks.

Run:  python3 bot.py --name bot1 --data run/node1 --port 8200 --key bot1
"""

from __future__ import annotations

import argparse
import os
import random
import sys
import threading
import time
from http.server import ThreadingHTTPServer
from typing import Any, Dict, List, Optional

import chain as chain_mod
import node as node_mod
import p2p as p2p_mod
from chain import Chain, fmt
from wallet import Wallet

HERE = os.path.dirname(os.path.abspath(__file__))
KEYDIR = os.path.join(HERE, "keys")


class Bot:
    def __init__(self, name: str, data: str, port: int, key: str,
                 peers: List[str], tx_every: float, mine_every: float,
                 duration: float, seed: Optional[int]):
        self.name = name
        self.port = port
        self.data = data
        self.tx_every = tx_every
        self.mine_every = mine_every
        self.duration = duration
        self.rng = random.Random(seed)
        chain_mod.DATA_DIR = data
        self.chain = Chain(data)
        self.wallet = Wallet.load(key, KEYDIR)
        self.pool = p2p_mod.PeerPool(self.chain, self_addr=f"127.0.0.1:{port}",
                                     sync_interval=0.5)
        for p in peers:
            self.pool.add_peer(p)
        self.httpd = ThreadingHTTPServer(("0.0.0.0", port),
                                        node_mod.make_handler(self.chain, self.pool))
        self.httpd.node_id = node_mod.node_id_for(data)
        self.sent = 0
        self.mined = 0
        self.moved = 0
        self.started = time.time()
        self.last_tx = 0.0
        self.last_mine = 0.0
        self.last_activity = time.time()
        self.stop = threading.Event()

    # -- helpers ---------------------------------------------------------
    def log(self, msg: str) -> None:
        print(f"[{self.name}] {time.strftime('%H:%M:%S')} {msg}", flush=True)

    def pick_recipient(self) -> Optional[str]:
        balances = self.chain.state()[0].get("qsam", {})
        choices = [a for a, v in balances.items()
                   if a != self.wallet.address and v > 0]
        return self.rng.choice(choices) if choices else None

    # -- actions ---------------------------------------------------------
    def send_one(self) -> None:
        to = self.pick_recipient()
        if not to:
            return
        bal = self.chain.balance(self.wallet.address, "qsam")
        amount = self.rng.randint(1, 250) * chain_mod.UNITS
        fee = 1_000
        if bal < amount + fee:
            return
        tx = self.wallet.make_tx(to, amount, fee,
                                 self.chain.next_nonce(self.wallet.address),
                                 int(time.time() * 1000),
                                 f"{self.name} transfer", asset="qsam")
        ok, why = self.chain.add_to_mempool(tx)
        if not ok:
            return
        self.sent += 1
        self.moved += amount
        self.last_activity = time.time()
        self.pool.broadcast_tx(tx)
        self.log(f"sent {fmt(amount)} QSAM -> {to[:9]}…")

    def mine_one(self) -> None:
        try:
            block = self.chain.mine(self.wallet.address, max_txs=40)
        except Exception as exc:            # mining races are expected, not fatal
            self.log(f"mine skipped: {exc}")
            return
        self.mined += 1
        self.last_mine = time.time()
        self.last_activity = time.time()
        q = block["header"]["quantum"]
        self.log(f"mined block {block['header']['height']} "
                 f"({q['amplification']}x work, {len(block['transactions'])} tx)")
        self.pool.broadcast_block(block)

    # -- loop ------------------------------------------------------------
    def run(self) -> None:
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        self.pool.start()
        self.log(f"up on :{self.port} · {len(self.pool.peers)} peer(s) · "
                 f"height {self.chain.height()} · balance "
                 f"{fmt(self.chain.balance(self.wallet.address, 'qsam'))} QSAM")
        try:
            while not self.stop.is_set():
                now = time.time()
                if self.duration and now - self.started > self.duration:
                    break
                if now - self.last_tx >= self.tx_every:
                    self.last_tx = now
                    try:
                        self.send_one()
                    except Exception as exc:
                        self.log(f"tx error: {exc}")
                pending = len(self.chain.mempool())
                due = now - self.last_mine >= self.mine_every
                idle = now - self.last_activity > 5.0
                if pending and due:
                    self.mine_one()
                elif idle and due:              # keep the chain alive when quiet
                    self.mine_one()
                time.sleep(0.4)
        finally:
            self.log(f"stopping · sent {self.sent} tx · mined {self.mined} blocks · "
                     f"height {self.chain.height()} · work {self.chain.cumulative_work()}x")
            self.pool.stop()
            self.httpd.shutdown()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", default="bot")
    ap.add_argument("--data", default="run/node1")
    ap.add_argument("--port", type=int, default=8200)
    ap.add_argument("--key", default="")
    ap.add_argument("--peer", action="append", default=[])
    ap.add_argument("--tx-every", type=float, default=3.0)
    ap.add_argument("--mine-every", type=float, default=2.0)
    ap.add_argument("--duration", type=float, default=0)
    ap.add_argument("--seed", type=int, default=None)
    a = ap.parse_args()
    bot = Bot(a.name, a.data, a.port, a.key or a.name, a.peer,
              a.tx_every, a.mine_every, a.duration, a.seed)
    bot.run()


if __name__ == "__main__":
    main()
