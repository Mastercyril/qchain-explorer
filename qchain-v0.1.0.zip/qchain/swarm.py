"""Start ONE node and let the policy grow the network.

Nothing here decides how many nodes exist. The seed reads policy.json, decides
it should replicate, and spawns children. Those children find the rest of the
network through peer exchange. This harness only watches and reports.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request

import socket

import replicate
from wallet import Wallet

HERE = os.path.dirname(os.path.abspath(__file__))
KEYS = os.path.join(HERE, "keys")
KILL = ("ps -eo pid,args | awk '$0 ~ /worker[.]py/ {print $1}' | xargs -r kill -9")


def get(port: int, path: str, timeout: float = 3.0):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=timeout) as r:
            return json.load(r)
    except Exception:
        return None


def kill_workers(wait: float = 6.0) -> None:
    """Kill every worker and wait until none are left, so ports really free up."""
    subprocess.run(["bash", "-lc", KILL], check=False)
    end = time.time() + wait
    while time.time() < end:
        left = subprocess.run(
            ["bash", "-lc", "ps -eo args | awk '$0 ~ /worker[.]py/' | wc -l"],
            capture_output=True, text=True).stdout.strip()
        if left in ("", "0"):
            return
        time.sleep(0.3)


def port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("0.0.0.0", port))
            return True
        except OSError:
            return False


def free_base(start: int, span: int = 12) -> int:
    port = start
    while port < start + 400:
        if all(port_free(port + i) for i in range(span)):
            return port
        port += span
    raise RuntimeError("no free port block")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="swarm")
    ap.add_argument("--port", type=int, default=9400)
    ap.add_argument("--duration", type=float, default=45)
    ap.add_argument("--policy", default="policy.json")
    args = ap.parse_args()

    root = os.path.join(HERE, args.root)
    shutil.rmtree(root, ignore_errors=True)
    os.makedirs(root, exist_ok=True)
    kill_workers()
    time.sleep(0.5)

    kill_workers()
    args.port = free_base(args.port)
    Wallet(name=f"w{args.port}").save(KEYS)
    print("=" * 74)
    print("SELF REPLICATING SWARM - one seed node, policy decides the rest")
    print("=" * 74)
    print(f"  seed :{args.port}   policy {args.policy}   running for {args.duration:.0f}s")
    print(f"  port block verified free before boot\n")

    log = open(os.path.join(root, "seed.log"), "w")
    seed = subprocess.Popen(
        [sys.executable, "worker.py", "--name", f"w{args.port}",
         "--data", os.path.join(root, f"node-{args.port}"),
         "--port", str(args.port), "--key", f"w{args.port}",
         "--policy", args.policy, "--depth", "0", "--root", args.root,
         "--genesis", "--duration", str(args.duration + 10)],
        cwd=HERE, stdout=log, stderr=subprocess.STDOUT)

    reg = replicate.Registry(args.root)
    agreed_samples = 0
    total_samples = 0
    end = time.time() + args.duration
    try:
        while time.time() < end:
            time.sleep(4)
            nodes = sorted(reg.nodes(), key=lambda n: n["port"])
            heights, heads = [], set()
            print(f"  t+{args.duration - (end - time.time()):4.0f}s   nodes {len(nodes)}")
            for n in nodes:
                h = get(int(n["port"]), "/p2p/hello")
                if not h:
                    print(f"      :{n['port']}  (starting)")
                    continue
                heights.append(h["height"])
                heads.add(h["head"])
                parent = n.get("parent_port") if n.get("parent_port") else "-"
                print(f"      :{n['port']}  depth {n['depth']}  height {h['height']:>3}"
                      f"  work {h['work']:>9.2f}x  peers {len(h.get('peers', []))}"
                      f"  parent {parent}")
            if heights:
                total_samples += 1
                if len(heads) == 1:
                    agreed_samples += 1
                    print(f"      -> all {len(nodes)} nodes on one head at height {max(heights)}")
                else:
                    print(f"      -> {len(heads)} heads in flight (normal while mining)")
            print()
    finally:
        # quiesce: stop all policy loops so blocks can propagate, then snapshot
        open(os.path.join(root, "PAUSE"), "w").close()
        print("  ... pausing all nodes so the chain can settle\n")
        time.sleep(4.5)
        snapshot = {}
        for n in reg.nodes():
            h = get(int(n["port"]), "/p2p/hello")
            if h:
                snapshot[int(n["port"])] = h
        seed.terminate()
        kill_workers()

    nodes = sorted(reg.nodes(), key=lambda n: n["port"])
    print("=" * 74)
    print("RESULT")
    print("=" * 74)
    print(f"  nodes created by the policy, not by the operator : {len(nodes)}")
    heads, heights, work = set(), [], 0.0
    valid = 0
    for n in nodes:
        port = int(n["port"])
        data = os.path.join(root, f"node-{port}")
        h = snapshot.get(port)
        if h:
            heads.add(h["head"])
            heights.append(h["height"])
            work = max(work, h["work"])
        ok = subprocess.run([sys.executable, "cli.py", "--data", data, "verify"],
                            cwd=HERE, capture_output=True, text=True).stdout
        if "VALID" in ok:
            valid += 1
    print(f"  chains that audit clean                          : {valid}/{len(nodes)}")
    print(f"  heads during the run                             : "
          f"{agreed_samples}/{total_samples} samples fully agreed")
    print(f"  heads after quiescing                            : "
          f"{'all identical' if len(heads) == 1 else str(len(heads)) + ' heads still differ'}")
    print(f"  tallest height                                   : {max(heights) if heights else 0}")
    print(f"  cumulative quantum work at the tip               : {work:.2f}x")


if __name__ == "__main__":
    main()
