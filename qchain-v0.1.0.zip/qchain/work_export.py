"""Export a chain's PoQW claims as TSV so a JVM verifier can re-derive them."""
import json
import sys


def export(chain_path: str, out_path: str) -> int:
    rows = 0
    with open(chain_path) as fh, open(out_path, "w") as out:
        out.write("# height\tprev\tmerkle\tminer\tts\tnonce\ttarget\tconcentration\tfingerprint\n")
        for line in fh:
            if not line.strip():
                continue
            b = json.loads(line)
            h, q = b["header"], b["header"]["quantum"]
            out.write("\t".join([
                str(h["height"]), h["prev_hash"], h["merkle_root"], h["miner"],
                str(h["timestamp"]), str(h["nonce"]), str(q["target_index"]),
                repr(float(q["concentration"])), q["state_fingerprint"],
            ]) + "\n")
            rows += 1
    return rows


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "demo_data/chain.jsonl"
    dst = sys.argv[2] if len(sys.argv) > 2 else "work.tsv"
    print(f"exported {export(src, dst)} blocks -> {dst}")
