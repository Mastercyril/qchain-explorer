"""
HTTP node + block explorer for the 13th Chamber chain.

Stdlib only. Run:  python3 node.py --port 8080
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, Tuple
from urllib.parse import parse_qs, urlparse

import chain as chain_mod
import p2p as p2p_mod
from chain import Chain, fmt
from wallet import verify_tx

HERE = os.path.dirname(os.path.abspath(__file__))


def make_handler(chain: Chain, pool: "p2p_mod.PeerPool | None" = None):

    class Handler(BaseHTTPRequestHandler):
        server_version = "13thChamberNode/1.0"

        # -- helpers -------------------------------------------------------
        def _json(self, payload: Any, code: int = 200) -> None:
            body = json.dumps(payload, indent=2).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

        def _html(self, path: str) -> None:
            full = os.path.join(HERE, path)
            if not os.path.exists(full):
                self._json({"error": "not found"}, 404)
                return
            with open(full, "rb") as fh:
                body = fh.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args) -> None:  # keep the console clean
            pass

        def _absorb_origin(self) -> None:
            """Inbound gossip makes the sender a peer, which is how the mesh forms."""
            origin = self.headers.get("X-Node-Addr")
            if origin and pool is not None:
                pool.add_peer(origin)

        # -- routes --------------------------------------------------------
        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            path = parsed.path.rstrip("/") or "/"
            query = parse_qs(parsed.query)

            if path == "/":
                self._html("explorer.html")
                return
            if path == "/api/status":
                view = chain.summary()
                if pool is not None:
                    view["p2p"] = {"peers": list(pool.peers),
                                   "peer_count": len(pool.peers),
                                   "stats": dict(pool.stats)}
                self._json(view)
                return

            # ---- peer-to-peer ----
            if path == "/p2p/hello":
                self._absorb_origin()
                self._json({
                    "node": getattr(self.server, "node_id", "unknown"),
                    "chain_id": chain.config["chain_id"],
                    "height": chain.height(),
                    "head": chain.head()["hash"] if chain.blocks else None,
                    "work": chain.cumulative_work(),
                    "blocks": len(chain.blocks),
                    "mempool": len(chain.mempool()),
                    "assets": list(chain_mod.ASSETS),
                    "quantum_threshold": chain.config["quantum_min_amplification"],
                    "peers": (pool.peers if pool else []),
                })
                return
            if path == "/p2p/blocks":
                start = int(query.get("from", ["0"])[0])
                self._json(chain.blocks_from(start))
                return
            if path == "/p2p/peers":
                self._json({"peers": list(pool.peers) if pool else []})
                return
            if path == "/p2p/stats":
                self._json(pool.status() if pool else {"peers": []})
                return
            if path == "/api/blocks":
                limit = int(query.get("limit", ["25"])[0])
                offset = int(query.get("offset", ["0"])[0])
                blocks = list(reversed(chain.blocks))[offset:offset + limit]
                self._json([self._block_view(b) for b in blocks])
                return
            if path.startswith("/api/block/"):
                ref = path.split("/")[-1]
                block = None
                for b in chain.blocks:
                    if str(b["header"]["height"]) == ref or b["hash"] == ref:
                        block = b
                        break
                if block is None:
                    self._json({"error": "block not found"}, 404)
                    return
                self._json(self._block_view(block, full=True))
                return
            if path == "/api/mempool":
                self._json(chain.mempool())
                return
            if path == "/api/verify":
                ok, errors = chain.validate()
                self._json({"valid": ok, "errors": errors,
                            "blocks_checked": len(chain.blocks),
                            "checked_at": int(time.time() * 1000)})
                return
            if path.startswith("/api/address/"):
                addr = path.split("/api/address/")[-1]
                bals = chain.balances_of(addr)
                self._json({
                    "address": addr,
                    "balances": {
                        "QSAM": fmt(bals["qsam"]),
                        "QBTC": fmt(bals["qbtc"]),
                    },
                    "qbtc_note": "non-transferable, not for sale",
                    "next_nonce": chain.next_nonce(addr),
                    "transactions": self._address_txs(addr),
                })
                return
            self._json({"error": "not found"}, 404)

        def do_POST(self) -> None:
            parsed = urlparse(self.path)
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b"{}"
            try:
                payload = json.loads(raw or b"{}")
            except json.JSONDecodeError:
                self._json({"error": "invalid json"}, 400)
                return

            if parsed.path.rstrip("/") == "/api/tx":
                ok, why = chain.add_to_mempool(payload)
                if ok and pool is not None:
                    threading.Thread(target=pool.broadcast_tx, args=(payload,),
                                     daemon=True).start()
                self._json({"accepted": ok, "detail": why}, 200 if ok else 400)
                return
            # ---- peer-to-peer ----
            if parsed.path.rstrip("/") == "/p2p/block":
                self._absorb_origin()
                result = chain.receive_block(payload)
                if result["status"] == "reorg" and pool is not None:
                    pool.stats["reorgs"] += 1
                if result.get("relay") and pool is not None:
                    threading.Thread(target=pool.broadcast_block, args=(payload,),
                                     daemon=True).start()
                self._json(result, 400 if result["status"] == "rejected" else 200)
                return
            if parsed.path.rstrip("/") == "/p2p/tx":
                self._absorb_origin()
                ok, why = chain.add_to_mempool(payload)
                if ok and pool is not None:
                    pool.stats["tx_in"] += 1
                    threading.Thread(target=pool.broadcast_tx, args=(payload,),
                                     daemon=True).start()
                self._json({"accepted": ok, "detail": why}, 200 if ok else 400)
                return
            if parsed.path.rstrip("/") == "/p2p/connect":
                addr = p2p_mod.normalise(payload.get("peer", ""))
                if not addr:
                    self._json({"error": "peer address required"}, 400)
                    return
                added = pool.add_peer(addr) if pool else False
                info = pool.hello(addr) if pool else None
                if pool is not None:
                    threading.Thread(target=pool.sync_from, args=(addr,),
                                     daemon=True).start()
                self._json({"added": added, "peer": addr, "hello": info})
                return
            if parsed.path.rstrip("/") == "/p2p/disconnect":
                addr = p2p_mod.normalise(payload.get("peer", ""))
                self._json({"removed": pool.remove_peer(addr) if pool else False,
                            "peer": addr})
                return
            if parsed.path.rstrip("/") == "/api/mine":
                miner = payload.get("miner") or chain.head()["header"]["miner"]
                try:
                    block = chain.mine(miner)
                except Exception as exc:
                    self._json({"error": str(exc)}, 500)
                    return
                if pool is not None:
                    threading.Thread(target=pool.broadcast_block, args=(block,),
                                     daemon=True).start()
                self._json({"mined": True, "height": block["header"]["height"],
                            "hash": block["hash"],
                            "amplification": round(
                                block["header"]["quantum"]["amplification"], 2),
                            "mined_ms": block["mined_ms"]})
                return
            self._json({"error": "not found"}, 404)

        # -- views ---------------------------------------------------------
        def _block_view(self, block: Dict[str, Any], full: bool = False) -> Dict[str, Any]:
            h = block["header"]
            q = h["quantum"]
            view = {
                "height": h["height"],
                "hash": block["hash"],
                "prev_hash": h["prev_hash"],
                "timestamp": h["timestamp"],
                "miner": h["miner"],
                "tx_count": h["tx_count"],
                "nonce": h["nonce"],
                "quantum": {
                    "target_bits": q["target_bits"],
                    "concentration_pct": round(q["concentration"] * 100, 4),
                    "baseline_pct": round(q["baseline"] * 100, 4),
                    "amplification": round(q["amplification"], 2),
                    "gate_count": q["gate_count"],
                    "n_qubits": q["n_qubits"],
                    "state_fingerprint": q["state_fingerprint"],
                },
                "mined_ms": block["mined_ms"],
                "nonces_tried": block["nonces_tried"],
            }
            if full:
                view["transactions"] = [
                    {
                        "hash": chain_mod.me(tx),
                        "asset": chain_mod.asset_of(tx).upper(),
                        "from": tx["from"],
                        "to": tx["to"],
                        "amount": fmt(int(tx["amount"])),
                        "fee": fmt(int(tx["fee"])),
                        "nonce": tx["nonce"],
                        "timestamp": tx["timestamp"],
                        "memo": tx.get("memo", ""),
                    }
                    for tx in block["transactions"]
                ]
                view["merkle_root"] = h["merkle_root"]
                view["challenge"] = q["challenge"]
            return view

        def _address_txs(self, addr: str) -> list:
            out = []
            for block in chain.blocks:
                for tx in block["transactions"]:
                    if addr in (tx.get("from"), tx.get("to")):
                        out.append({
                            "hash": chain_mod.me(tx)[:16],
                            "asset": chain_mod.asset_of(tx).upper(),
                            "height": block["header"]["height"],
                            "from": tx["from"],
                            "to": tx["to"],
                            "amount": fmt(int(tx["amount"])),
                            "direction": "in" if tx.get("to") == addr else "out",
                        })
            return out

    return Handler


def node_id_for(data_dir: str) -> str:
    """Stable short identity for this node, kept beside the chain."""
    path = os.path.join(data_dir, "node_id.txt")
    if os.path.exists(path):
        with open(path) as fh:
            existing = fh.read().strip()
            if existing:
                return existing
    fresh = hashlib.sha256(os.urandom(32)).hexdigest()[:12]
    with open(path, "w") as fh:
        fh.write(fresh)
    return fresh


def serve(port: int = 8080, data_dir: str = chain_mod.DATA_DIR,
          peers=None, sync: bool = True, sync_interval: float = 2.0) -> None:
    chain_mod.DATA_DIR = data_dir
    chain = Chain(data_dir)
    if not chain.blocks:
        print("chain is empty - run: python3 cli.py init, or point --peer at a node that has one")

    pool = p2p_mod.PeerPool(chain, self_addr=f"127.0.0.1:{port}",
                            sync_interval=sync_interval)
    for addr in (peers or []):
        pool.add_peer(addr)

    httpd = ThreadingHTTPServer(("0.0.0.0", port), make_handler(chain, pool))
    httpd.node_id = node_id_for(data_dir)

    print(f"13th Chamber node {httpd.node_id} listening on http://localhost:{port}")
    print(f"  explorer : http://localhost:{port}/")
    print(f"  status   : http://localhost:{port}/api/status")
    print(f"  height   : {chain.height()}   work: {chain.cumulative_work()}x")
    print(f"  peers    : {', '.join(pool.peers) if pool.peers else 'none'}")
    if sync:
        pool.start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nnode stopped")
    finally:
        pool.stop()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--data", default=chain_mod.DATA_DIR)
    ap.add_argument("--peer", action="append", default=[],
                    help="host:port of a peer (repeatable)")
    ap.add_argument("--no-sync", action="store_true",
                    help="serve but do not run the gossip loop")
    ap.add_argument("--sync-interval", type=float, default=2.0)
    args = ap.parse_args()
    serve(args.port, args.data, peers=args.peer,
          sync=not args.no_sync, sync_interval=args.sync_interval)
