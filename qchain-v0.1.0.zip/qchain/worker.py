"""A node whose behaviour comes from policy.json rather than from its code.

It serves the same HTTP + P2P API as node.py, and on every tick it observes
facts, evaluates the rules, and performs exactly one action. Because the rules
are data, behaviour can be upgraded by shipping a new policy.

    python3 worker.py --name w8100 --data run/node-8100 --port 8100 \
        --key w8100 --policy policy.json --depth 0 --root run --genesis
"""

from __future__ import annotations

import argparse
import os
import random
import threading
import time
from http.server import ThreadingHTTPServer

import chain as chain_mod
import node as node_mod
import p2p as p2p_mod
import replicate
import rules
from chain import Chain
from wallet import Wallet

HERE = os.path.dirname(os.path.abspath(__file__))
KEYS = os.path.join(HERE, "keys")


class Worker:
    def __init__(self, a: argparse.Namespace):
        self.a = a
        self.chain = Chain(a.data)
        self.wallet = Wallet.load(a.key, KEYS)
        self.policy = rules.load_policy(a.policy)
        self.registry = replicate.Registry(a.root)
        self.self_addr = f"127.0.0.1:{a.port}"
        self.pool = p2p_mod.PeerPool(self.chain, self_addr=self.self_addr, sync_interval=0.5)
        for p in a.peer:
            self.pool.add_peer(p)
        self.httpd = ThreadingHTTPServer(("0.0.0.0", a.port),
                                         node_mod.make_handler(self.chain, self.pool))
        self.httpd.node_id = node_mod.node_id_for(a.data)
        # keep the parent recorded by whoever spawned us; only the seed has none
        prior = next((n for n in self.registry.nodes() if int(n["port"]) == a.port), None)
        self.registry.add({"name": a.name, "port": a.port, "depth": a.depth,
                           "peers": list(a.peer), "pid": os.getpid(),
                           "parent_port": (prior or {}).get("parent_port"),
                           "started": time.time()})
        self.children = []
        self.last_spawn = 0.0
        self.last_action = time.time()
        if a.genesis and not self.chain.blocks:
            # the first node bootstraps the ledger and becomes its treasury
            qbtc = Wallet(name="qbtc_treasury")
            qbtc.save(KEYS)
            self.chain.create_genesis(self.wallet.address, qbtc.address)
            print(f"[{a.port}] genesis created, treasury {self.wallet.address}", flush=True)

    def start(self) -> None:
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        self.pool.start()

    def facts(self) -> dict:
        return {
            "height": self.chain.height(),
            "peers": len(self.pool.peers),
            "mempool": len(self.chain.mempool()),
            "nodes_known": self.registry.count(),
            "depth": self.a.depth,
            "children": len(self.children),
            "idle_s": time.time() - self.last_action,
            "cooldown_ready": (time.time() - self.last_spawn) >= float(
                self.policy.get("guardrails", {}).get("spawn_cooldown_s", 3)),
            "have_seed": bool(self.a.seed),
            "balance": self.chain.balance(self.wallet.address) // chain_mod.UNITS,
            "chain_work": self.chain.cumulative_work(),
            "protocol_ok": True,
        }

    def recipients(self) -> list:
        cands = set()
        for n in self.registry.nodes():
            try:
                cands.add(Wallet.load(n["name"], KEYS).address)
            except Exception:
                pass
        cands |= {a for a, b in self.chain.state()[0].get("qsam", {}).items() if b > 0}
        cands.discard(self.wallet.address)
        return sorted(cands)

    def act(self, action: dict) -> str:
        kind = action["action"]
        if kind == "bootstrap":
            if self.a.seed:
                self.pool.add_peer(self.a.seed)
                self.pool.learn_from(self.a.seed)
            for port in self.registry.ports():
                if port != self.a.port:
                    self.pool.add_peer(f"127.0.0.1:{port}")
            return f"joined seed {self.a.seed} ({len(self.pool.peers)} peers)"
        if kind == "spawn_child":
            ok, why = rules.allow_spawn(self.policy, self.registry.count(),
                                        self.a.depth, time.time() - self.last_spawn)
            if not ok:
                return f"blocked: {why}"
            port = self.registry.alloc_port(self.a.port + 1)
            name = f"w{port}"
            try:
                proc = replicate.spawn(self.a.root, name, port, [self.self_addr],
                                       self.a.depth + 1, self.a.policy, self.self_addr,
                                       parent_port=self.a.port)
                self.children.append(proc)
                self.last_spawn = time.time()
                return f"spawned {name} on :{port}"
            except Exception as exc:
                return f"spawn failed: {exc}"
        if kind == "mine":
            try:
                block = self.chain.mine(self.wallet.address)
                self.pool.broadcast_block(block)
                self.last_action = time.time()
                amp = block["header"]["quantum"]["amplification"]
                return f"mined block {block['header']['height']} ({amp:.2f}x)"
            except Exception as exc:
                return f"mine skipped: {exc}"
        if kind == "send":
            to = random.choice(self.recipients()) if self.recipients() else None
            if not to:
                return "no recipient yet"
            try:
                amount = random.randint(150, 700) * chain_mod.UNITS
                tx = self.wallet.make_tx(
                    to, amount, int(self.chain.config["min_fee"]),
                    self.chain.next_nonce(self.wallet.address),
                    int(time.time() * 1000), "swarm")
                ok, why = self.chain.add_to_mempool(tx)
                if ok:
                    self.pool.broadcast_tx(tx)
                    self.last_action = time.time()
                return f"sent {amount // chain_mod.UNITS} QSAM -> {to[:8]} ({why})"
            except Exception as exc:
                return f"send failed: {exc}"
        return f"unknown action {kind}"

    def run(self, duration: float) -> None:
        end = time.time() + duration if duration else None
        pause_file = os.path.join(self.a.root, "PAUSE")
        while not (end and time.time() > end):
            if os.path.exists(pause_file):
                time.sleep(0.4)
                continue
            decided = rules.decide(self.policy, self.facts())
            if decided:
                line = self.act(decided[0])
                print(f"[{self.name():<7}] {decided[0]['rule']:<22} {line}", flush=True)
            time.sleep(1.0)

    def name(self) -> str:
        return f":{self.a.port}"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--key", required=True)
    ap.add_argument("--policy", default="policy.json")
    ap.add_argument("--depth", type=int, default=0)
    ap.add_argument("--root", required=True)
    ap.add_argument("--seed", default="")
    ap.add_argument("--peer", action="append", default=[])
    ap.add_argument("--genesis", action="store_true")
    ap.add_argument("--duration", type=float, default=0)
    args = ap.parse_args()
    w = Worker(args)
    w.start()
    try:
        w.run(args.duration)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
