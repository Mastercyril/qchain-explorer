package qchain

import java.math.BigDecimal
import java.math.RoundingMode
import java.security.MessageDigest

/** Kotlin mirror of quantum.py. Same circuit, same numbers, on the JVM. */
object Poqw {
    const val N_QUBITS = 6
    const val DIM = 1 shl N_QUBITS
    const val BASELINE = 1.0 / DIM
    private const val TWO_PI = 2.0 * Math.PI

    fun sha256(vararg parts: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        for (p in parts) md.update(p)
        return md.digest()
    }

    fun be32(v: Int): ByteArray =
        byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())

    /** Deterministic byte stream expanded from a challenge, exactly as quantum.py does. */
    fun stream(challenge: ByteArray, length: Int): ByteArray {
        val out = ArrayList<Byte>()
        var counter = 0
        while (out.size < length) {
            sha256(challenge, be32(counter)).forEach { out.add(it) }
            counter++
        }
        return ByteArray(length) { out[it] }
    }

    class Op(val kind: String, val a: Int, val b: Int, val theta: Double)

    /** s6.1 ansatz: rotations then a ring of entanglers, two layers deep. */
    fun circuit(challenge: ByteArray, depth: Int = 2): List<Op> {
        val s = stream(challenge, depth * N_QUBITS * 2)
        val ops = ArrayList<Op>()
        var pos = 0
        for (layer in 0 until depth) {
            for (q in 0 until N_QUBITS) {
                val u16 = ((s[pos].toInt() and 0xFF) shl 8) or (s[pos + 1].toInt() and 0xFF)
                pos += 2
                var theta = TWO_PI * (u16 / 65536.0)
                if (layer % 2 == 1) theta = -theta
                ops.add(Op("ry", q, 0, theta))
            }
            for (q in 0 until N_QUBITS) ops.add(Op("cnot", q, (q + 1) % N_QUBITS, 0.0))
        }
        return ops
    }

    /** Run the ops on |00..0>; returns probabilities of each outcome. */
    fun probabilities(ops: List<Op>): DoubleArray {
        val re = DoubleArray(DIM)
        val im = DoubleArray(DIM)
        re[0] = 1.0
        for (op in ops) {
            if (op.kind == "ry") {
                val c = Math.cos(op.theta / 2.0)
                val s = Math.sin(op.theta / 2.0)
                val step = 1 shl op.a
                var base = 0
                while (base < DIM) {
                    for (i in base until base + step) {
                        val lr = re[i]; val li = im[i]
                        val hr = re[i + step]; val hi = im[i + step]
                        re[i] = c * lr - s * hr
                        im[i] = c * li - s * hi
                        re[i + step] = s * lr + c * hr
                        im[i + step] = s * li + c * hi
                    }
                    base += step shl 1
                }
            } else {
                val cbit = 1 shl op.a
                val tbit = 1 shl op.b
                for (i in 0 until DIM) {
                    if ((i and cbit) != 0 && (i and tbit) == 0) {
                        val j = i or tbit
                        val tr = re[i]; val ti = im[i]
                        re[i] = re[j]; im[i] = im[j]
                        re[j] = tr; im[j] = ti
                    }
                }
            }
        }
        return DoubleArray(DIM) { re[it] * re[it] + im[it] * im[it] }
    }

    fun targetOutcome(challenge: ByteArray): Int {
        val d = sha256("target|".toByteArray(), challenge)
        var v = 0L
        for (i in 0 until 8) v = (v shl 8) or (d[i].toLong() and 0xFF)
        return (v and (DIM - 1).toLong()).toInt()
    }

    fun challenge(prevHash: String, merkleRoot: String, miner: String, ts: Long, nonce: Long): ByteArray =
        sha256("poqw|".toByteArray(), "$prevHash|$merkleRoot|$miner|$ts|$nonce".toByteArray())

    class Work(
        val targetIndex: Int,
        val concentration: Double,
        val amplification: Double,
        val fingerprint: String,
        val gateCount: Int,
    )

    fun work(ch: ByteArray): Work {
        val ops = circuit(ch)
        val probs = probabilities(ops)
        val target = targetOutcome(ch)
        val md = MessageDigest.getInstance("SHA-256")
        for (p in probs) {
            val r = BigDecimal(p).setScale(12, RoundingMode.HALF_EVEN).toDouble()
            val bits = java.lang.Double.doubleToLongBits(r)
            for (shift in intArrayOf(56, 48, 40, 32, 24, 16, 8, 0))
                md.update(((bits ushr shift) and 0xFF).toByte())
        }
        val fp = md.digest().joinToString("") { "%02x".format(it) }.substring(0, 32)
        return Work(target, probs[target], probs[target] / BASELINE, fp, ops.size)
    }
}
