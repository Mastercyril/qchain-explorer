package qchain

import java.io.File
import kotlin.system.exitProcess

/**
 * Independent JVM verifier: reads blocks exported by the Python node and
 * re-derives every Proof-of-Quantum-Work claim from scratch.
 *
 * usage: java -jar verify.jar work.tsv
 * columns: height prev_hash merkle_root miner timestamp nonce target concentration fingerprint
 */
fun main(args: Array<String>) {
    if (args.isEmpty()) {
        println("usage: verify.jar <work.tsv>")
        exitProcess(2)
    }
    val rows = File(args[0]).readLines().filter { it.isNotBlank() && !it.startsWith("#") }
    var ok = 0
    var bad = 0
    println("height  target    concentration    amplification  fingerprint      verdict")
    println("-".repeat(78))
    for (row in rows) {
        val f = row.split("\t")
        if (f.size < 9) { println("malformed row: $row"); bad++; continue }
        val height = f[0].trim()
        val prev = f[1].trim(); val merkle = f[2].trim(); val miner = f[3].trim()
        val ts = f[4].trim().toLong(); val nonce = f[5].trim().toLong()
        val claimedTarget = f[6].trim().toInt()
        val claimedConc = f[7].trim().toDouble()
        val claimedFp = f[8].trim()

        val ch = Poqw.challenge(prev, merkle, miner, ts, nonce)
        val w = Poqw.work(ch)

        val targetOk = w.targetIndex == claimedTarget
        val concOk = Math.abs(w.concentration - claimedConc) <= 1e-9
        val fpOk = w.fingerprint == claimedFp
        val pass = targetOk && concOk && fpOk
        if (pass) ok++ else bad++

        val note = when {
            !targetOk -> "TARGET MISMATCH"
            !concOk -> "CONCENTRATION MISMATCH"
            !fpOk -> "FINGERPRINT MISMATCH"
            else -> "ok"
        }
        println(
            "%-7s |%s>  %14.10f  %12.4fx  %s  %s".format(
                height,
                String.format("%6s", Integer.toBinaryString(w.targetIndex)).replace(' ', '0'),
                w.concentration, w.amplification, w.fingerprint, note
            )
        )
    }
    println("-".repeat(78))
    println("blocks verified: $ok   mismatched: $bad")
    if (bad == 0) println("RESULT: every PoQW claim reproduced on the JVM")
    exitProcess(if (bad == 0) 0 else 1)
}
