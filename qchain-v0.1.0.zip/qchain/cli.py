#!/usr/bin/env python3
"""
Command line for the 13th Chamber chain.

    python3 cli.py init                      create genesis (needs a treasury key)
    python3 cli.py wallet new alice          create a signing key
    python3 cli.py wallets                   list local keys and balances
    python3 cli.py send alice <addr> 10      queue a signed transaction
    python3 cli.py mine treasury --blocks 3  mine blocks from the mempool
    python3 cli.py verify                    full audit of every block
    python3 cli.py status                    chain summary
    python3 cli.py serve --port 8080         run the node + explorer
    python3 cli.py demo                      build a fresh demo chain end to end
    python3 cli.py tamper                    prove tampering is detected
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import time

import chain as chain_mod
from chain import Chain, fmt, UNITS
from wallet import Wallet

KEYDIR = "keys"


def qsam_to_units(text: str) -> int:
    return int(round(float(text) * UNITS))


def load_wallet(name: str) -> Wallet:
    path = os.path.join(KEYDIR, f"{name}.key.json")
    if not os.path.exists(path):
        sys.exit(f"no key named '{name}'. run: python3 cli.py wallet new {name}")
    return Wallet.load(name, KEYDIR)


def ensure_treasury() -> Wallet:
    if not os.path.exists(os.path.join(KEYDIR, "treasury.key.json")):
        w = Wallet(name="treasury")
        w.save(KEYDIR)
        print(f"created treasury wallet {w.address}")
        return w
    return Wallet.load("treasury", KEYDIR)


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------

def cmd_init(args) -> None:
    chain = Chain(args.data)
    if chain.blocks:
        sys.exit(f"chain already initialised at height {chain.height()}")
    treasury = ensure_treasury()
    print(f"minting genesis supply to treasury {treasury.address}")
    block = chain.create_genesis(treasury.address)
    ok, errors = chain.validate()
    print(f"genesis mined in {block['mined_ms']}ms "
          f"({block['nonces_tried']} nonces, "
          f"{block['header']['quantum']['amplification']:.2f}x amplification)")
    print(f"chain valid: {ok}" + ("" if ok else f" {errors}"))


def cmd_wallet_new(args) -> None:
    if os.path.exists(os.path.join(KEYDIR, f"{args.name}.key.json")):
        sys.exit(f"key '{args.name}' already exists")
    w = Wallet(name=args.name)
    path = w.save(KEYDIR)
    print(f"created {args.name}")
    print(f"  address: {w.address}")
    print(f"  keyfile: {path}  (keep this private)")


def cmd_wallets(args) -> None:
    chain = Chain(args.data)
    if not os.path.isdir(KEYDIR):
        print("no local keys yet")
        return
    print(f"{'name':<14}{'address':<38}{'QSAM':>16}{'QBTC':>16}{'nonce':>8}")
    for fn in sorted(os.listdir(KEYDIR)):
        if not fn.endswith(".key.json"):
            continue
        w = Wallet.load(fn.replace(".key.json", ""), KEYDIR)
        b = chain.balances_of(w.address)
        print(f"{w.name:<14}{w.address:<38}{fmt(b['qsam']):>16}{fmt(b['qbtc']):>16}"
              f"{chain.next_nonce(w.address):>8}")


def cmd_send(args) -> None:
    chain = Chain(args.data)
    wallet = load_wallet(args.wallet)
    amount = qsam_to_units(args.amount)
    fee = qsam_to_units(args.fee)
    tx = wallet.make_tx(
        to=args.to,
        amount_units=amount,
        fee_units=fee,
        nonce=chain.next_nonce(wallet.address),
        timestamp_ms=int(time.time() * 1000),
        memo=args.memo or "",
        asset=args.asset,
    )
    ok, why = chain.add_to_mempool(tx)
    print(f"{'queued' if ok else 'rejected'}: {why}")
    if ok:
        print(f"  from {wallet.address} -> {args.to}  {fmt(amount)} {args.asset.upper()}  (nonce {tx['nonce']})")
    else:
        sys.exit(1)


def cmd_mine(args) -> None:
    chain = Chain(args.data)
    if not chain.blocks:
        sys.exit("no genesis block. run: python3 cli.py init")
    miner = load_wallet(args.miner)
    for i in range(args.blocks):
        pending = len(chain.mempool())
        if pending == 0 and not args.empty:
            print("mempool is empty - nothing to mine (use --empty to mine a blank block)")
            return
        block = chain.mine(miner.address, verbose=args.verbose)
        q = block["header"]["quantum"]
        print(f"block {block['header']['height']:>4}  {block['hash'][:16]}...  "
              f"{block['header']['tx_count']} tx  "
              f"{q['amplification']:.2f}x quantum work  "
              f"{block['mined_ms']}ms")


def cmd_verify(args) -> None:
    chain = Chain(args.data)
    started = time.time()
    ok, errors = chain.validate()
    elapsed = int((time.time() - started) * 1000)
    print(f"blocks checked : {len(chain.blocks)}")
    print(f"time           : {elapsed}ms")
    print(f"result         : {'VALID' if ok else 'INVALID'}")
    for err in errors:
        print(f"  - {err}")
    sys.exit(0 if ok else 1)


def cmd_status(args) -> None:
    chain = Chain(args.data)
    print(json.dumps(chain.summary(), indent=2))


def cmd_address(args) -> None:
    chain = Chain(args.data)
    balances, nonces = chain.state()
    print(f"address  : {args.address}")
    b = chain.balances_of(args.address)
    print(f"QSAM     : {fmt(b['qsam'])}")
    print(f"QBTC     : {fmt(b['qbtc'])}  (non-transferable)")
    print(f"nonce    : {chain.next_nonce(args.address)}")
    print("history  :")
    found = False
    for block in chain.blocks:
        for tx in block["transactions"]:
            if args.address in (tx.get("from"), tx.get("to")):
                found = True
                sign = "+" if tx["to"] == args.address else "-"
                asset = tx.get("asset", "qsam").upper()
                print(f"  block {block['header']['height']:>3}  {sign}{fmt(int(tx['amount'])):>16} "
                      f"{asset:<5} {(tx.get('memo') or '')[:34]}")
    if not found:
        print("  no transactions yet")


def cmd_tamper(args) -> None:
    """Mutate a confirmed block in memory and show the audit catching it."""
    chain = Chain(args.data)
    if len(chain.blocks) < 2:
        sys.exit("need at least 2 blocks to demo tampering")
    target = chain.blocks[1]
    original = json.loads(json.dumps(target))
    tx = target["transactions"][0]
    before = tx["amount"]
    tx["amount"] = int(before) * 1000
    print("attempting to rewrite history:")
    print(f"  block {target['header']['height']} tx amount {fmt(before)} -> {fmt(tx['amount'])}")
    ok, errors = chain.validate()
    print(f"\naudit result: {'VALID' if ok else 'REJECTED AS INVALID'}")
    for err in errors[:6]:
        print(f"  - {err}")
    chain.blocks[1] = original
    ok2, _ = chain.validate()
    print(f"\nrestored original block, audit: {'VALID' if ok2 else 'INVALID'}")


def cmd_demo(args) -> None:
    """Build a complete two-asset chain from scratch and exercise every rule."""
    data = args.data
    if os.path.isdir(data):
        shutil.rmtree(data)
    os.makedirs(data, exist_ok=True)
    chain_mod.DATA_DIR = data
    bar = "=" * 68
    print(bar)
    print("13TH CHAMBER CHAIN - TWO ASSET END TO END DEMO")
    print(bar)

    treasury      = Wallet(name="treasury")
    qbtc_treasury = Wallet(name="qbtc_treasury")
    alice         = Wallet(name="alice")
    bob           = Wallet(name="bob")
    for w in (treasury, qbtc_treasury, alice, bob):
        w.save(KEYDIR)
        print(f"{w.name:<15}{w.address}")

    chain = Chain(data)

    print("\n[1] genesis mints both assets exactly once")
    g = chain.create_genesis(treasury.address, qbtc_treasury.address,
                             timestamp_ms=1_800_000_000_000)
    for tx in g["transactions"]:
        spec = chain_mod.ASSETS[tx["asset"]]
        flag = "transferable" if spec["transferable"] else "LOCKED, not for sale"
        print(f"    {spec['symbol']:<5}{fmt(int(tx['amount'])):>18}"
              f"  -> {tx['to'][:22]}...  {flag}")
    print(f"    genesis {g['hash'][:22]}...  {g['mined_ms']}ms  "
          f"{g['header']['quantum']['amplification']:.2f}x quantum work")

    print("\n[2] queue signed QSAM transfers")
    def send(wallet, to, amount, memo, asset="qsam"):
        tx = wallet.make_tx(to, qsam_to_units(amount), 1_000,
                            chain.next_nonce(wallet.address),
                            int(time.time() * 1000), memo, asset=asset)
        ok, why = chain.add_to_mempool(tx)
        print(f"    {asset.upper():<5}{wallet.name:<9} -> {amount:>7}"
              f"  {why}")
        return ok

    for _ in range(6):
        send(treasury, alice.address, "10000", "welcome bonus")
        send(treasury, bob.address, "2500", "daily rewards")
    print(f"    mempool holds {len(chain.mempool())} transactions")

    print("\n[3] QBTC is non-transferable, enforced at three layers")
    print("    a) mempool admission:")
    send(qbtc_treasury, alice.address, "100", "attempt one", asset="qbtc")
    print("    b) block validation:")
    bypass = qbtc_treasury.make_tx(alice.address, qsam_to_units("1"), 1_000,
                                   chain.next_nonce(qbtc_treasury.address),
                                   int(time.time() * 1000), "bypass", asset="qbtc")
    sneaky = chain_mod.mine_block(chain.head(), [bypass], treasury.address,
                                  chain.config, timestamp_ms=int(time.time() * 1000))
    ok_b, errs_b = chain.validate_block(sneaky, chain.head())
    print(f"       block accepted? {ok_b}  ->  {errs_b[0] if errs_b else 'no error'}")
    print("    c) full chain audit would also refuse to load it")

    print("\n[4] mining blocks (real quantum work per block)")
    for i in range(3):
        b = chain.mine(treasury.address, max_txs=4,
                       timestamp_ms=int(time.time() * 1000) + i * 1000)
        q = b["header"]["quantum"]
        print(f"    block {b['header']['height']}  {b['header']['tx_count']} tx  "
              f"{q['amplification']:>6.2f}x  |{q['target_bits']}>  "
              f"{b['mined_ms']:>5}ms  {b['nonces_tried']} nonces")

    print("\n[5] balances after mining")
    print(f"    {'wallet':<15}{'QSAM':>18}{'QBTC':>18}")
    for w in (treasury, qbtc_treasury, alice, bob):
        bb = chain.balances_of(w.address)
        print(f"    {w.name:<15}{fmt(bb['qsam']):>18}{fmt(bb['qbtc']):>18}")

    print("\n[6] full audit")
    ok, errors = chain.validate()
    print(f"    {'VALID' if ok else 'INVALID'}  ({len(chain.blocks)} blocks)")
    for e in errors:
        print(f"      - {e}")

    print("\n[7] double-spend attempt")
    spend = chain.balance(alice.address)
    bad = alice.make_tx(bob.address, spend * 2, 1_000, chain.next_nonce(alice.address),
                        int(time.time() * 1000), "spending twice")
    ok2, why2 = chain.add_to_mempool(bad)
    print(f"    rejected: {not ok2}  ({why2})")

    print("\n[8] forged signature attempt")
    forged = treasury.make_tx(alice.address, qsam_to_units("1"), 1_000,
                              chain.next_nonce(treasury.address),
                              int(time.time() * 1000), "forged")
    forged["amount"] = qsam_to_units("999999")
    ok3, why3 = chain.add_to_mempool(forged)
    print(f"    rejected: {not ok3}  ({why3})")

    print("\n[9] tamper with a confirmed block")
    original = json.loads(json.dumps(chain.blocks[1]))
    chain.blocks[1]["transactions"][0]["amount"] *= 1000
    ok4, errors4 = chain.validate()
    print(f"    audit after tampering: {'VALID' if ok4 else 'INVALID'}")
    for e in errors4[:3]:
        print(f"      - {e}")
    chain.blocks[1] = original
    ok5, _ = chain.validate()
    print(f"    audit after restore:   {'VALID' if ok5 else 'INVALID'}")

    print("\n[10] supply invariants, per asset")
    balances, _ = chain.state()
    for asset, spec in chain_mod.ASSETS.items():
        total = sum(balances.get(asset, {}).values())
        match = total == spec["supply"]
        print(f"    {spec['symbol']:<5}{fmt(total):>18} == {fmt(spec['supply']):>18} : {match}")

    print("\n" + bar)
    print(f"demo chain written to {data}/chain.jsonl")
    print(f"run the explorer:  python3 node.py --data {data} --port 8080")
    print(bar)


def main() -> None:
    ap = argparse.ArgumentParser(description="13th Chamber chain CLI")
    ap.add_argument("--data", default=None, help="data directory")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init")

    p = sub.add_parser("wallet"); p.add_argument("name")
    sub.add_parser("wallets")

    p = sub.add_parser("send")
    p.add_argument("wallet"); p.add_argument("to"); p.add_argument("amount")
    p.add_argument("--fee", default="0.001"); p.add_argument("--memo", default="")
    p.add_argument("--asset", default="qsam", choices=["qsam", "qbtc"])

    p = sub.add_parser("mine")
    p.add_argument("miner", nargs="?", default="treasury")
    p.add_argument("--blocks", type=int, default=1)
    p.add_argument("--empty", action="store_true", help="allow mining with an empty mempool")
    p.add_argument("--verbose", action="store_true")

    sub.add_parser("verify")
    sub.add_parser("status")
    sub.add_parser("tamper")

    p = sub.add_parser("serve")
    p.add_argument("--port", type=int, default=8080)
    p.add_argument("--peer", action="append", default=[], help="host:port (repeatable)")

    sub.add_parser("demo")

    p = sub.add_parser("address"); p.add_argument("address")

    args = ap.parse_args()
    # demo builds its own scratch chain unless the caller names a directory
    args.data = args.data or ("demo_data" if args.cmd == "demo" else chain_mod.DATA_DIR)
    chain_mod.DATA_DIR = args.data

    handlers = {
        "init": cmd_init, "wallet": cmd_wallet_new, "wallets": cmd_wallets,
        "send": cmd_send, "mine": cmd_mine, "verify": cmd_verify,
        "status": cmd_status, "tamper": cmd_tamper, "demo": cmd_demo,
        "address": cmd_address,
    }
    if args.cmd == "serve":
        import node
        node.serve(args.port, args.data, peers=args.peer)
        return
    handlers[args.cmd](args)


if __name__ == "__main__":
    main()
