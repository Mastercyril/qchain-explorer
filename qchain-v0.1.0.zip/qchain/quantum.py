"""
Proof-of-Quantum-Work (PoQW) circuit layer for the 13th Chamber chain.

Implements a pure-Python statevector simulator (no numpy, no network) so the
quantum work behind every block is fully reproducible and auditable by anyone
who has this file.

The consensus metric mirrors the whitepaper (quantum-crypto-wp.md, s6.1 + s8.2):
a parameterised circuit is prepared from a challenge derived from the previous
block hash, the transaction Merkle root and the miner's nonce. The circuit's
output distribution concentrates probability on one target bitstring. The
concentration, measured against the uniform-random baseline, is the work score.

    baseline        = 1 / 2**n_qubits
    concentration   = P(target outcome)
    amplification   = concentration / baseline        e.g. 12.5x

A miner searches nonces until the circuit amplifies above the network threshold.
Every other node re-runs the same circuit and must reproduce the same number.
"""

from __future__ import annotations

import hashlib
import math
import struct
from typing import Dict, List, Sequence, Tuple

N_QUBITS = 6                      # 2**6 = 64 outcomes
DIM = 1 << N_QUBITS
BASELINE = 1.0 / DIM              # 1.5625%  -- the whitepaper's "random" line
TWO_PI = 2.0 * math.pi

Op = Tuple[str, int, int, float]  # (kind, a, b, theta)


# --------------------------------------------------------------------------
# circuit construction
# --------------------------------------------------------------------------

def _stream(challenge: bytes, length: int) -> bytes:
    """Deterministic byte stream expanded from a challenge."""
    out = bytearray()
    counter = 0
    while len(out) < length:
        out += hashlib.sha256(challenge + struct.pack(">I", counter)).digest()
        counter += 1
    return bytes(out[:length])


def circuit_from_challenge(challenge: bytes, depth: int = 2) -> List[Op]:
    """
    Build the PoQW ansatz from a challenge.

    Layout per layer: single-qubit rotations, then a ring of entanglers.
    Rotations use 16-bit angle resolution so the circuit is portable across
    languages and machines without floating point drift in the inputs.
    """
    n = N_QUBITS
    stream = _stream(challenge, depth * n * 2)
    ops: List[Op] = []
    pos = 0
    for layer in range(depth):
        for q in range(n):
            u16 = (stream[pos] << 8) | stream[pos + 1]
            pos += 2
            theta = TWO_PI * (u16 / 65536.0)
            # alternate a phase-inverted layer to create interference
            if layer % 2 == 1:
                theta = -theta
            ops.append(("ry", q, 0, theta))
        for q in range(n):
            ops.append(("cnot", q, (q + 1) % n, 0.0))
    return ops


def simulate(ops: Sequence[Op]) -> List[complex]:
    """Run the ops on |00..0> and return the statevector."""
    state: List[complex] = [0j] * DIM
    state[0] = 1 + 0j
    for kind, a, b, theta in ops:
        if kind == "ry":
            c, s = math.cos(theta / 2.0), math.sin(theta / 2.0)
            step = 1 << a
            for base in range(0, DIM, step << 1):
                for i in range(base, base + step):
                    lo, hi = state[i], state[i + step]
                    state[i] = c * lo - s * hi
                    state[i + step] = s * lo + c * hi
        elif kind == "cnot":
            cbit, tbit = 1 << a, 1 << b
            for i in range(DIM):
                if (i & cbit) and not (i & tbit):
                    j = i | tbit
                    state[i], state[j] = state[j], state[i]
        else:  # pragma: no cover - defensive
            raise ValueError(f"unknown op {kind}")
    return state


def probabilities(state: Sequence[complex]) -> List[float]:
    """Measurement distribution."""
    return [abs(amp) ** 2 for amp in state]


def target_outcome(challenge: bytes) -> int:
    """Which bitstring the miner must amplify, chosen from the challenge."""
    digest = hashlib.sha256(b"target|" + challenge).digest()
    mask = DIM - 1
    return int.from_bytes(digest[:8], "big") & mask


def work_result(challenge: bytes) -> Dict[str, object]:
    """
    The verifiable claim inside a block.

    Returns the target outcome, its measured probability, the amplification
    over random and a fingerprint of the prepared state so two nodes can prove
    they ran the identical circuit.
    """
    ops = circuit_from_challenge(challenge)
    state = simulate(ops)
    probs = probabilities(state)
    target = target_outcome(challenge)
    concentration = probs[target]

    # global fingerprint of the state, insensitive to float noise in the last bits
    fp = hashlib.sha256(
        b"".join(struct.pack(">d", round(p, 12)) for p in probs)
    ).hexdigest()[:32]

    return {
        "n_qubits": N_QUBITS,
        "gate_count": len(ops),
        "target_index": target,
        "target_bits": format(target, f"0{N_QUBITS}b"),
        "concentration": concentration,
        "baseline": BASELINE,
        "amplification": concentration / BASELINE,
        "state_fingerprint": fp,
    }


def verify_work(challenge: bytes, claim: Dict[str, object],
                tolerance: float = 1e-9) -> Tuple[bool, str]:
    """
    Re-derive the work and compare it to what the block claims.

    This is what makes PoQW a proof rather than a number a miner typed in.
    """
    recomputed = work_result(challenge)
    if int(claim.get("target_index", -1)) != recomputed["target_index"]:
        return False, "target outcome mismatch"
    claimed = float(claim.get("concentration", -1.0))
    actual = float(recomputed["concentration"])
    if abs(claimed - actual) > tolerance:
        return False, f"concentration mismatch ({claimed:.12f} vs {actual:.12f})"
    if claim.get("state_fingerprint") and claim["state_fingerprint"] != recomputed["state_fingerprint"]:
        return False, "state fingerprint mismatch"
    return True, "ok"


# --------------------------------------------------------------------------
# challenge derivation
# --------------------------------------------------------------------------

def make_challenge(prev_hash: str, merkle_root: str, miner: str,
                   timestamp_ms: int, nonce: int) -> bytes:
    """
    s6.1: challenge derived from the previous block hash, the pending
    transaction Merkle root and the current timestamp, plus the mining nonce.
    """
    preimage = "|".join([
        prev_hash, merkle_root, miner, str(timestamp_ms), str(nonce),
    ]).encode()
    return hashlib.sha256(b"poqw|" + preimage).digest()
