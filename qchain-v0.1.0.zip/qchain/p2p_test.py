"""
Live peer-to-peer integration test for the 13th Chamber chain.

Spins up real node processes on real ports, then proves:
  1. a fresh node adopts genesis from a peer
  2. a mined block reaches every peer
  3. a transaction gossips, then confirms on a different node
  4. a block smuggling QBTC is refused over the wire
  5. a block with an inflated quantum claim is refused over the wire
  6. two partitioned chains that diverge then reconnect converge on the branch
     with more cumulative quantum work, and the loser reorgs
  7. every node's chain still audits clean afterwards

Run:  python3 p2p_test.py
"""

from __future__ import annotations

import copy
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

import chain as chain_mod
from chain import Chain
from wallet import Wallet

HERE = os.path.dirname(os.path.abspath(__file__))
SYNC_INTERVAL = "0.4"
RESULTS = []


# --------------------------------------------------------------------- http
def http_get(url: str, timeout: float = 5.0):
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        return json.loads(resp.read() or b"null")


def http_post(url: str, payload, timeout: float = 8.0):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read() or b"null")
    except urllib.error.HTTPError as exc:
        return json.loads(exc.read() or b"null")


def wait_until(label: str, predicate, timeout: float = 25.0, interval: float = 0.25):
    deadline = time.time() + timeout
    last_error = None
    while time.time() < deadline:
        try:
            value = predicate()
            if value:
                return value
        except Exception as exc:                       # node still booting
            last_error = exc
        time.sleep(interval)
    raise AssertionError(f"timed out waiting for {label}" + (f" ({last_error})" if last_error else ""))


def free_port(start: int) -> int:
    port = start
    while port < start + 200:
        with socket.socket() as sock:
            if sock.connect_ex(("127.0.0.1", port)) != 0:
                return port
        port += 1
    raise RuntimeError("no free port")


def node_url(port: int, path: str) -> str:
    return f"http://127.0.0.1:{port}{path}"


# ------------------------------------------------------------------- fixture
def build_template(root: str):
    """A genesis chain plus the keys the test needs, shared by every node."""
    template = os.path.join(root, "template")
    os.makedirs(template, exist_ok=True)
    keys = os.path.join(template, "keys")
    os.makedirs(keys, exist_ok=True)

    chain_mod.DATA_DIR = template
    treasury = Wallet(name="treasury")
    qbtc_treasury = Wallet(name="qbtc_treasury")
    alice = Wallet(name="alice")
    for w in (treasury, qbtc_treasury, alice):
        w.save(keys)

    chain = Chain(template)
    chain.save_config(quantum_min_amplification=12.5, difficulty=0)
    genesis = chain.create_genesis(treasury.address, qbtc_treasury.address,
                                   timestamp_ms=1_800_000_000_000)
    return {
        "dir": template,
        "keys": keys,
        "treasury": treasury,
        "qbtc_treasury": qbtc_treasury,
        "alice": alice,
        "genesis_hash": genesis["hash"],
        "chain": chain,
    }


def spawn_node(data_dir: str, port: int, peers=None, extra=None):
    cmd = [sys.executable, "node.py", "--data", data_dir, "--port", str(port),
           "--sync-interval", SYNC_INTERVAL]
    for peer in (peers or []):
        cmd += ["--peer", peer]
    cmd += (extra or [])
    log = open(os.path.join(data_dir, f"node-{port}.log"), "w")
    proc = subprocess.Popen(cmd, cwd=HERE, stdout=log, stderr=subprocess.STDOUT)
    return proc, log


def clone_data(template: dict, dest: str, with_chain: bool = True) -> str:
    os.makedirs(dest, exist_ok=True)
    shutil.copy(os.path.join(template["dir"], "config.json"),
                os.path.join(dest, "config.json"))
    if with_chain:
        shutil.copy(os.path.join(template["dir"], "chain.jsonl"),
                    os.path.join(dest, "chain.jsonl"))
    with open(os.path.join(dest, "mempool.json"), "w") as fh:
        fh.write("[]")
    return dest


def record(name: str, ok: bool, detail: str) -> None:
    RESULTS.append((name, ok, detail))
    print(f"  {'PASS' if ok else 'FAIL'}  {name}\n        {detail}")


# ---------------------------------------------------------------------- main
def main() -> int:
    root = tempfile.mkdtemp(prefix="qchain-p2p-")
    procs = []
    started = time.time()
    print("=" * 74)
    print("PEER TO PEER INTEGRATION TEST")
    print("=" * 74)

    try:
        template = build_template(root)
        print(f"template genesis {template['genesis_hash'][:20]}...")
        print(f"work root {root}\n")

        # ---- three nodes: A is the seed, B and C follow it
        port_a, port_b, port_c = free_port(18401), free_port(18501), free_port(18601)
        dir_a = clone_data(template, os.path.join(root, "a"))
        dir_b = clone_data(template, os.path.join(root, "b"))
        dir_c = clone_data(template, os.path.join(root, "c"))

        for d, port, peers in ((dir_a, port_a, []),
                               (dir_b, port_b, [f"127.0.0.1:{port_a}"]),
                               (dir_c, port_c, [f"127.0.0.1:{port_a}",
                                                f"127.0.0.1:{port_b}"])):
            proc, log = spawn_node(d, port, peers)
            procs.append((proc, log))

        for port in (port_a, port_b, port_c):
            wait_until(f"node {port} up", lambda p=port: http_get(node_url(p, "/p2p/hello")))
        print("  three nodes up\n")

        # ---- 1. a brand new node adopts genesis from a peer
        port_f = free_port(18701)
        dir_f = clone_data(template, os.path.join(root, "f"), with_chain=False)
        proc, log = spawn_node(dir_f, port_f, [f"127.0.0.1:{port_a}"])
        procs.append((proc, log))
        wait_until("node F up", lambda: http_get(node_url(port_f, "/p2p/hello")))
        head_f = wait_until("F to adopt genesis",
                            lambda: http_get(node_url(port_f, "/p2p/hello"))["head"])
        record("new node adopts genesis over the wire",
               head_f == template["genesis_hash"],
               f"head {head_f[:20]}... from an empty data directory")

        # ---- 2. block propagation
        mined = http_post(node_url(port_a, "/api/mine"), {})
        def all_at(height: int):
            heads = [http_get(node_url(p, "/p2p/hello")) for p in (port_a, port_b, port_c)]
            if all(h["height"] == height for h in heads):
                return {h["head"] for h in heads}
            return None
        consensus = wait_until("block to reach B and C", lambda: all_at(mined["height"]))
        record("mined block reaches every peer",
               len(consensus) == 1,
               f"height {mined['height']} identical head on A, B, C: "
               f"{list(consensus)[0][:20]}...")

        # ---- 3. transaction gossip across nodes
        alice = template["alice"]
        treasury = template["treasury"]
        chain_b = Chain(dir_b)
        tx = treasury.make_tx(alice.address, 5_000 * chain_mod.UNITS, 1_000,
                              chain_b.next_nonce(treasury.address),
                              int(time.time() * 1000), "gossip test", asset="qsam")
        accepted = http_post(node_url(port_b, "/api/tx"), tx)
        wait_until("tx to reach A and C",
                   lambda: all(len(http_get(node_url(p, "/api/mempool"))) >= 1
                               for p in (port_a, port_c)))
        mined_c = http_post(node_url(port_c, "/api/mine"), {})
        wait_until("block to settle everywhere",
                   lambda: all(http_get(node_url(p, "/p2p/hello"))["height"] == mined_c["height"]
                               for p in (port_a, port_b)))
        found = False
        for block in http_get(node_url(port_a, "/api/blocks?limit=20")):
            detail = http_get(node_url(port_a, f"/api/block/{block['height']}"))
            if any(t["from"] == treasury.address and t["memo"] == "gossip test"
                   for t in detail.get("transactions", [])):
                found = True
                break
        record("transaction gossips to peers then confirms on another node",
               bool(accepted.get("accepted")) and found,
               f"submitted on B, mined on C, present in A's block {mined_c['height']}")

        # ---- 4. a block smuggling QBTC is refused over the wire
        head = http_get(node_url(port_a, "/p2p/blocks?from=0"))[-1]
        cfg = json.load(open(os.path.join(dir_a, "config.json")))
        qbtc_tx = template["qbtc_treasury"].make_tx(
            alice.address, 1_000_000, 1_000, 0,
            int(time.time() * 1000), "smuggle", asset="qbtc")
        smuggled = chain_mod.mine_block(head, [qbtc_tx], treasury.address, cfg,
                                        timestamp_ms=int(time.time() * 1000))
        before = http_get(node_url(port_a, "/p2p/hello"))
        verdict = http_post(node_url(port_a, "/p2p/block"), smuggled)
        after = http_get(node_url(port_a, "/p2p/hello"))
        record("peer refuses a block that moves QBTC",
               verdict.get("status") == "rejected" and "non-transferable" in verdict.get("detail", "")
               and before["head"] == after["head"],
               f"{verdict.get('status')}: {verdict.get('detail')[:64]}")

        # ---- 5. a block with an inflated quantum claim is refused
        fake = copy.deepcopy(head)
        fake["header"]["quantum"]["concentration"] *= 2.0
        fake["header"]["quantum"]["amplification"] *= 2.0
        fake["hash"] = chain_mod.block_hash(fake["header"])
        verdict2 = http_post(node_url(port_a, "/p2p/block"), fake)
        after2 = http_get(node_url(port_a, "/p2p/hello"))
        record("peer refuses an inflated quantum claim",
               verdict2.get("status") == "rejected" and "quantum" in verdict2.get("detail", "").lower()
               and after2["head"] == after["head"],
               f"{verdict2.get('status')}: {verdict2.get('detail')[:64]}")

        # ---- 6. partition, diverge, reconnect, converge on more work
        port_p, port_q = free_port(18801), free_port(18901)
        dir_p = clone_data(template, os.path.join(root, "p"))
        dir_q = clone_data(template, os.path.join(root, "q"))
        proc_p, log_p = spawn_node(dir_p, port_p, [])
        proc_q, log_q = spawn_node(dir_q, port_q, [])
        procs += [(proc_p, log_p), (proc_q, log_q)]
        for port in (port_p, port_q):
            wait_until(f"node {port} up", lambda p=port: http_get(node_url(p, "/p2p/hello")))

        http_post(node_url(port_p, "/api/mine"), {})          # P: one block
        light_head = http_get(node_url(port_p, "/p2p/hello"))
        for _ in range(3):                                     # Q: three blocks
            http_post(node_url(port_q, "/api/mine"), {})
        heavy_head = http_get(node_url(port_q, "/p2p/hello"))
        print(f"        P: height {light_head['height']} work {light_head['work']}x   "
              f"Q: height {heavy_head['height']} work {heavy_head['work']}x")

        http_post(node_url(port_p, "/p2p/connect"), {"peer": f"127.0.0.1:{port_q}"})
        wait_until("P to reorg onto the heavier branch",
                   lambda: http_get(node_url(port_p, "/p2p/hello"))["head"] == heavy_head["head"])
        wait_until("Q to keep its own branch",
                   lambda: http_get(node_url(port_q, "/p2p/hello"))["head"] == heavy_head["head"])
        stats_p = http_get(node_url(port_p, "/p2p/stats"))
        record("partitioned chains converge on the branch with more quantum work",
               stats_p["stats"]["reorgs"] >= 1,
               f"P abandoned {light_head['work']}x for {heavy_head['work']}x "
               f"({stats_p['stats']['reorgs']} reorg), both now at height {heavy_head['height']}")

        # ---- 7. every chain still audits clean
        audits = {p: http_get(node_url(p, "/api/verify")) for p in
                  (port_a, port_b, port_c, port_f, port_p, port_q)}
        all_clean = all(a["valid"] for a in audits.values())
        record("every node's chain still audits clean",
               all_clean,
               ", ".join(f"{p}: {'valid' if a['valid'] else a['errors'][:1]}"
                         for p, a in audits.items()))

    finally:
        for proc, log in procs:
            try:
                proc.terminate()
                proc.wait(timeout=6)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
            try:
                log.close()
            except Exception:
                pass

    passed = sum(1 for _, ok, _ in RESULTS if ok)
    total = len(RESULTS)
    elapsed = time.time() - started
    print("\n" + "=" * 74)
    print(f"{passed}/{total} network checks passed in {elapsed:.1f}s")
    print("=" * 74)
    for name, ok, _ in RESULTS:
        if not ok:
            print(f"  FAILED: {name}")
            print(f"  logs are under {root}")
    if passed == total:
        shutil.rmtree(root, ignore_errors=True)
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
