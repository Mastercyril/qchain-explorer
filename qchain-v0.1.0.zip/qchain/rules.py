"""Logic-driven execution: a tiny deterministic rule engine.

Nodes do not have hardcoded behaviour. They observe a set of facts and evaluate
ordered rules from policy.json. Same facts in, same action out, every time, on
any node. That makes node behaviour auditable and upgradeable without touching
code: ship a new policy, not a new binary.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

FACTS: List[str] = [
    "height", "peers", "mempool", "nodes_known", "depth", "children",
    "idle_s", "cooldown_ready", "have_seed", "balance", "chain_work",
    "protocol_ok",
]

_OPS = {
    "lt": lambda a, b: a < b,
    "lte": lambda a, b: a <= b,
    "gt": lambda a, b: a > b,
    "gte": lambda a, b: a >= b,
    "eq": lambda a, b: a == b,
    "ne": lambda a, b: a != b,
}


def load_policy(path: str) -> Dict[str, Any]:
    with open(path) as fh:
        policy = json.load(fh)
    unknown = [r["name"] for r in policy.get("rules", [])
               if not _valid_rule(r)]
    if unknown:
        raise ValueError(f"malformed rules: {unknown}")
    return policy


def _valid_rule(rule: Dict[str, Any]) -> bool:
    if "name" not in rule or "when" not in rule or "then" not in rule:
        return False
    return "action" in rule["then"]


def _check(node: Dict[str, Any], facts: Dict[str, Any]) -> bool:
    """Evaluate one condition tree. Unrecognised keys fail closed."""
    if not isinstance(node, dict):
        return False
    if "all" in node:
        return all(_check(c, facts) for c in node["all"])
    if "any" in node:
        return any(_check(c, facts) for c in node["any"])
    if "not" in node:
        return not _check(node["not"], facts)
    for fact, test in node.items():
        if fact not in FACTS:
            return False
        value = facts.get(fact)
        if not isinstance(test, dict):
            if value != test:
                return False
            continue
        for op, target in test.items():
            fn = _OPS.get(op)
            if fn is None or value is None:
                return False
            try:
                if not fn(value, target):
                    return False
            except TypeError:
                return False
    return True


def decide(policy: Dict[str, Any], facts: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return the action of the first rule that fires, or an empty list."""
    for rule in policy.get("rules", []):
        if _check(rule["when"], facts):
            action = dict(rule["then"])
            action["rule"] = rule["name"]
            return [action]
    return []


def allow_spawn(policy: Dict[str, Any], nodes_known: int, depth: int,
                seconds_since_spawn: float) -> tuple[bool, str]:
    """Guardrails. Self-replication without limits is a fork bomb."""
    g = policy.get("guardrails", {})
    max_nodes = int(g.get("max_nodes", 8))
    max_depth = int(g.get("max_depth", 1))
    cooldown = float(g.get("spawn_cooldown_s", 3))
    if nodes_known >= max_nodes:
        return False, f"at max_nodes ({max_nodes})"
    if depth >= max_depth:
        return False, f"at max_depth ({max_depth})"
    if seconds_since_spawn < cooldown:
        return False, "cooldown"
    return True, "ok"
