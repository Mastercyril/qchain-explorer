"""Boot a bot network: fund wallets, spawn autonomous nodes, watch them converge.

    python3 botnet.py --bots 5 --duration 30

Each bot is a real node on a real port with its own data directory. They gossip
blocks and transactions to each other and mine on their own schedules, so forks,
reorgs and convergence all happen for real rather than being simulated.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from typing import Dict, List

import chain as chain_mod
from chain import Chain, fmt
from wallet import Wallet

HERE = os.path.dirname(os.path.abspath(__file__))
KEYDIR = os.path.join(HERE, "keys")


def http_get(url: str, timeout: float = 4.0):
    from urllib.request import urlopen, Request
    try:
        with urlopen(Request(url, headers={"Accept": "application/json"}),
                     timeout=timeout) as r:
            return json.loads(r.read().decode())
    except Exception:
        return None


def prepare(workdir: str, bots: int, fund: int) -> Dict[str, object]:
    shutil.rmtree(workdir, ignore_errors=True)
    os.makedirs(workdir, exist_ok=True)
    chain_mod.DATA_DIR = workdir
    chain = Chain(workdir)

    treasury = Wallet(name="bn_treasury")
    qbtc_treasury = Wallet(name="bn_qbtc_treasury")
    treasury.save(KEYDIR)
    qbtc_treasury.save(KEYDIR)
    wallet_names = []
    wallets = {}
    for i in range(1, bots + 1):
        w = Wallet(name=f"bot{i}")
        w.save(KEYDIR)
        wallets[f"bot{i}"] = w
        wallet_names.append(f"bot{i}")

    chain.create_genesis(treasury.address, qbtc_treasury.address,
                         timestamp_ms=int(time.time() * 1000))
    for name in wallet_names:
        tx = treasury.make_tx(wallets[name].address, fund * chain_mod.UNITS,
                              1_000, chain.next_nonce(treasury.address),
                              int(time.time() * 1000), f"funding {name}", asset="qsam")
        ok, why = chain.add_to_mempool(tx)
        if not ok:
            raise RuntimeError(f"funding failed for {name}: {why}")
    block = chain.mine(treasury.address, max_txs=100)
    return {"chain": chain, "wallets": wallets, "names": wallet_names,
            "funded_in": block["header"]["height"], "treasury": treasury}


def spawn(workdir: str, bots: int, port_base: int, names: List[str],
          duration: float) -> List[subprocess.Popen]:
    logs = os.path.join(workdir, "logs")
    os.makedirs(logs, exist_ok=True)
    procs = []
    seed = f"127.0.0.1:{port_base}"
    for i, name in enumerate(names, start=1):
        data = os.path.join(workdir, f"node{i}")
        shutil.rmtree(data, ignore_errors=True)
        shutil.copytree(os.path.join(workdir, "chain"), data)
        peers: List[str] = [] if i == 1 else ["--peer", seed]
        args = [sys.executable, "bot.py", "--name", name, "--data", data,
                "--port", str(port_base + i - 1), "--key", name,
                "--tx-every", "2.5", "--mine-every", "1.5",
                "--duration", str(duration + 6)] + peers
        fh = open(os.path.join(logs, f"{name}.log"), "w")
        procs.append(subprocess.Popen(args, cwd=HERE, stdout=fh, stderr=subprocess.STDOUT))
    return procs


def report(port_base: int, bots: int, names: List[str]) -> Dict[str, object]:
    rows = []
    for i, name in enumerate(names):
        port = port_base + i
        h = http_get(f"http://127.0.0.1:{port}/p2p/hello")
        st = http_get(f"http://127.0.0.1:{port}/p2p/stats") or {}
        if not h:
            rows.append((name, port, None, None, None, None, None))
            continue
        rows.append((name, port, h["height"], h["work"], h["mempool"],
                     len(st.get("peers", [])), st.get("stats", {}).get("reorgs", 0)))
    return {"rows": rows}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bots", type=int, default=5)
    ap.add_argument("--port-base", type=int, default=8200)
    ap.add_argument("--fund", type=int, default=5000)
    ap.add_argument("--duration", type=float, default=30.0)
    ap.add_argument("--dir", default="botnet")
    a = ap.parse_args()

    workdir = os.path.join(HERE, a.dir)
    print("=" * 74)
    print(f"BOOTING A {a.bots} BOT NETWORK")
    print("=" * 74)
    state = prepare(os.path.join(workdir, "chain"), a.bots, a.fund)
    print(f"  genesis + funding block mined into block {state['funded_in']}, "
          f"each bot funded with {a.fund:,} QSAM")

    procs = spawn(workdir, a.bots, a.port_base, state["names"], a.duration)
    print(f"  {len(procs)} bots spawned, ports "
          f"{a.port_base}-{a.port_base + a.bots - 1}\n")

    started = time.time()
    headers = f"{'bot':<7}{'port':>6}{'height':>8}{'work':>11}{'pool':>6}{'peers':>7}{'reorgs':>8}"
    try:
        while time.time() - started < a.duration:
            time.sleep(4)
            data = report(a.port_base, a.bots, state["names"])
            print(headers)
            for r in data["rows"]:
                name, port, h, w, mp, pc, rg = r
                if h is None:
                    print(f"{name:<7}{port:>6}{'down':>8}")
                else:
                    print(f"{name:<7}{port:>6}{h:>8}{str(w) + 'x':>11}{mp:>6}{pc:>7}{rg:>8}")
            print()
    except KeyboardInterrupt:
        pass
    finally:
        for p in procs:
            p.send_signal(signal.SIGTERM)
        for p in procs:
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                p.kill()

    print("=" * 74)
    print("FINAL STATE")
    print("=" * 74)
    heights, works, heads, tx_total, reorgs, valid = [], [], [], 0, 0, 0
    for i, name in enumerate(state["names"]):
        data = os.path.join(workdir, f"node{i + 1}")
        chain = Chain(data)
        ok, errs = chain.validate()
        valid += 1 if ok else 0
        balances = chain.state()[0]["qsam"]
        total = sum(balances.values())
        tx_total += sum(len(b["transactions"]) for b in chain.blocks)
        heights.append(chain.height())
        works.append(chain.cumulative_work())
        heads.append(chain.head()["hash"][:12] if chain.head() else "-")
        status = "valid" if ok else f"INVALID {errs[0][:40]}"
        print(f"  {name:<7} height {chain.height():>3}  work {chain.cumulative_work():>8}x  "
              f"head {chain.head()['hash'][:12]}  supply {fmt(total)}  {status}")
    print()
    converged = len(set(heads)) == 1
    print(f"  blocks mined across the network : {max(heights)}")
    print(f"  transactions in the winning chain: {tx_total}")
    print(f"  nodes with a valid chain         : {valid}/{len(state['names'])}")
    print(f"  every node on the same head      : {converged}")
    print(f"  quantum work at the tip          : {works[0] if works else 0}x")
    print("=" * 74)


if __name__ == "__main__":
    main()
