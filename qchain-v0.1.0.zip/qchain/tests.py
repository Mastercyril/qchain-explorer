"""
Test suite for the 13th Chamber chain.

    python3 tests.py            (or: python3 -m unittest tests -v)
"""

from __future__ import annotations

import copy
import hashlib
import json
import os
import shutil
import tempfile
import time
import unittest

import chain as chain_mod
import quantum
from chain import (ASSETS, Chain, DEFAULT_CONFIG, QBTC_SUPPLY, QSAM_SUPPLY,
                   fmt, merkle_root)
from wallet import Wallet, verify_tx


def fast_config(**over) -> dict:
    cfg = dict(DEFAULT_CONFIG)
    cfg.update({"quantum_min_amplification": 2.0, "difficulty": 0})
    cfg.update(over)
    return cfg


class QuantumWorkTests(unittest.TestCase):
    def test_simulator_is_deterministic(self):
        challenge = bytes.fromhex("ab" * 32)
        a = quantum.work_result(challenge)
        b = quantum.work_result(challenge)
        self.assertEqual(a["concentration"], b["concentration"])
        self.assertEqual(a["state_fingerprint"], b["state_fingerprint"])
        self.assertEqual(a["target_index"], b["target_index"])

    def test_statevector_is_normalised(self):
        state = quantum.simulate(quantum.circuit_from_challenge(b"\x01" * 32))
        total = sum(abs(amp) ** 2 for amp in state)
        self.assertAlmostEqual(total, 1.0, places=10)

    def test_varied_challenges_give_varied_work(self):
        scores = set()
        for i in range(12):
            ch = quantum.make_challenge("0" * 64, "a" * 64, "miner", 1000, i)
            scores.add(round(quantum.work_result(ch)["amplification"], 6))
        self.assertGreater(len(scores), 8, "work must actually depend on the challenge")

    def test_verifier_rejects_inflated_claim(self):
        ch = quantum.make_challenge("0" * 64, "b" * 64, "miner", 2000, 7)
        claim = dict(quantum.work_result(ch))
        claim["concentration"] = min(1.0, claim["concentration"] * 3 + 0.05)
        ok, why = quantum.verify_work(ch, claim)
        self.assertFalse(ok)
        self.assertIn("mismatch", why)

    def test_verifier_rejects_wrong_target(self):
        ch = quantum.make_challenge("0" * 64, "c" * 64, "miner", 3000, 1)
        claim = dict(quantum.work_result(ch))
        claim["target_index"] = (claim["target_index"] + 1) % quantum.DIM
        ok, _ = quantum.verify_work(ch, claim)
        self.assertFalse(ok)

    def test_challenge_binds_previous_hash(self):
        a = quantum.make_challenge("0" * 64, "d" * 64, "m", 1, 0)
        b = quantum.make_challenge("1" * 64, "d" * 64, "m", 1, 0)
        self.assertNotEqual(a, b)


class MerkleTests(unittest.TestCase):
    @staticmethod
    def h(char: str) -> str:
        return hashlib.sha256(char.encode()).hexdigest()

    def test_order_matters(self):
        self.assertNotEqual(merkle_root([self.h("a"), self.h("b")]),
                            merkle_root([self.h("b"), self.h("a")]))

    def test_single_and_empty(self):
        self.assertEqual(len(merkle_root([self.h("a")])), 64)
        self.assertEqual(len(merkle_root([])), 64)

    def test_odd_count_is_stable(self):
        three = [self.h("a"), self.h("b"), self.h("c")]
        self.assertEqual(merkle_root(three), merkle_root(three))
        self.assertNotEqual(merkle_root(three), merkle_root(three + [self.h("d")]))


class WalletTests(unittest.TestCase):
    def test_signature_roundtrip(self):
        w = Wallet(name="t1")
        tx = w.make_tx("qdest", 1000, 10, 0, 12345, "hello")
        ok, why = verify_tx(tx)
        self.assertTrue(ok, why)

    def test_tampered_amount_breaks_signature(self):
        w = Wallet(name="t2")
        tx = w.make_tx("qdest", 1000, 10, 0, 12345, "hello")
        tx["amount"] = 10 ** 12
        ok, why = verify_tx(tx)
        self.assertFalse(ok)
        self.assertEqual(why, "bad signature")

    def test_cannot_claim_someone_elses_address(self):
        w = Wallet(name="t3")
        other = Wallet(name="t4")
        tx = w.make_tx("qdest", 1000, 10, 0, 1, "")
        tx["from"] = other.address
        ok, why = verify_tx(tx)
        self.assertFalse(ok)
        self.assertIn("address does not belong", why)

    def test_keyfile_roundtrip(self):
        w = Wallet(name="keyfile")
        tmp = tempfile.mkdtemp()
        try:
            w.save(tmp)
            loaded = Wallet.load("keyfile", tmp)
            self.assertEqual(loaded.address, w.address)
        finally:
            shutil.rmtree(tmp)


class ChainTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.cfg = fast_config()
        self.treasury = Wallet(name="treasury")
        self.alice = Wallet(name="alice")
        self.bob = Wallet(name="bob")
        self.chain = Chain(self.tmp)
        # persist the fast config so a reloaded chain uses the same rules
        self.chain.save_config(quantum_min_amplification=2.0, difficulty=0)
        self.chain.create_genesis(self.treasury.address, timestamp_ms=1_700_000_000_000)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _send(self, wallet, to, amount, memo=""):
        tx = wallet.make_tx(to, amount, 1_000, self.chain.next_nonce(wallet.address),
                            int(time.time() * 1000), memo)
        return self.chain.add_to_mempool(tx), tx

    def test_genesis_mints_full_supply(self):
        self.assertEqual(self.chain.balance(self.treasury.address, "qsam"), QSAM_SUPPLY)

    def test_genesis_mints_the_qbtc_registry(self):
        _bal, _ = self.chain.state()
        self.assertEqual(self.chain.balance(self.treasury.address, "qbtc"), QBTC_SUPPLY)

    def test_valid_chain_passes_audit(self):
        self._send(self.treasury, self.alice.address, 5_000 * chain_mod.UNITS)
        self.chain.mine(self.treasury.address)
        ok, errors = self.chain.validate()
        self.assertTrue(ok, errors)

    def test_balance_moves_after_mining(self):
        amount = 5_000 * chain_mod.UNITS
        self._send(self.treasury, self.alice.address, amount)
        self.chain.mine(self.treasury.address)
        self.assertEqual(self.chain.balance(self.alice.address), amount)

    def test_overspend_rejected(self):
        ok, why = self._send(self.alice, self.bob.address, 10 * chain_mod.UNITS)[0]
        self.assertFalse(ok)
        self.assertIn("insufficient QSAM", why)

    def test_bad_nonce_rejected(self):
        tx = self.treasury.make_tx(self.alice.address, 1_000, 1_000, 99,
                                   int(time.time() * 1000), "")
        ok, why = self.chain.add_to_mempool(tx)
        self.assertFalse(ok)
        self.assertIn("bad nonce", why)

    def test_fee_below_minimum_rejected(self):
        tx = self.treasury.make_tx(self.alice.address, 1_000, 0,
                                   self.chain.next_nonce(self.treasury.address),
                                   int(time.time() * 1000), "")
        ok, why = self.chain.add_to_mempool(tx)
        self.assertFalse(ok)
        self.assertIn("fee below", why)

    def test_double_spend_across_mempool_rejected(self):
        bal = 1_000 * chain_mod.UNITS
        self._send(self.treasury, self.alice.address, bal)
        self.chain.mine(self.treasury.address)
        first, _ = self._send(self.alice, self.bob.address, bal - 2_000)
        self.assertTrue(first[0], first[1])
        second, _ = self._send(self.alice, self.bob.address, bal - 2_000)
        self.assertFalse(second[0])
        self.assertIn("insufficient QSAM", second[1])

    def test_tampered_transaction_fails_audit(self):
        self._send(self.treasury, self.alice.address, 100 * chain_mod.UNITS)
        self.chain.mine(self.treasury.address)
        self.chain.blocks[1]["transactions"][0]["amount"] *= 100
        ok, errors = self.chain.validate()
        self.assertFalse(ok)
        self.assertTrue(any("merkle" in e for e in errors))

    def test_broken_chain_link_fails_audit(self):
        self._send(self.treasury, self.alice.address, 100 * chain_mod.UNITS)
        self.chain.mine(self.treasury.address)
        self.chain.blocks[1]["header"]["prev_hash"] = "f" * 64
        ok, errors = self.chain.validate()
        self.assertFalse(ok)
        self.assertTrue(any("prev_hash" in e for e in errors))

    def test_forged_quantum_claim_fails_audit(self):
        self._send(self.treasury, self.alice.address, 100 * chain_mod.UNITS)
        self.chain.mine(self.treasury.address)
        self.chain.blocks[1]["header"]["quantum"]["concentration"] += 0.25
        ok, errors = self.chain.validate()
        self.assertFalse(ok)
        self.assertTrue(any("quantum work invalid" in e for e in errors))

    def test_threshold_is_enforced(self):
        self.chain.config = fast_config(quantum_min_amplification=999.0)
        block = chain_mod.mine_block(self.chain.head(), [], self.treasury.address,
                                     fast_config(quantum_min_amplification=2.0),
                                     timestamp_ms=int(time.time() * 1000))
        ok, errors = self.chain.validate_block(block, self.chain.head())
        self.assertFalse(ok)
        self.assertTrue(any("below network threshold" in e for e in errors))

    def test_supply_never_changes(self):
        for _ in range(3):
            self._send(self.treasury, self.alice.address, 1_000 * chain_mod.UNITS)
            self.chain.mine(self.treasury.address)
        balances, _ = self.chain.state()
        for asset, spec in ASSETS.items():
            self.assertEqual(sum(balances.get(asset, {}).values()), spec["supply"],
                             f"{asset} supply drifted")

    def test_persistence_across_reload(self):
        self._send(self.treasury, self.alice.address, 777 * chain_mod.UNITS)
        self.chain.mine(self.treasury.address)
        reloaded = Chain(self.tmp)
        self.assertEqual(reloaded.height(), 1)
        self.assertEqual(reloaded.balance(self.alice.address), 777 * chain_mod.UNITS)
        ok, _ = reloaded.validate()
        self.assertTrue(ok)


class MultiAssetTests(unittest.TestCase):
    """QBTC is a register of custody: it must never be spendable."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.treasury = Wallet(name="tsam")
        self.qbtc_treasury = Wallet(name="tbtc")
        self.alice = Wallet(name="alice")
        self.chain = Chain(self.tmp)
        self.chain.save_config(quantum_min_amplification=2.0, difficulty=0)
        self.chain.create_genesis(self.treasury.address, self.qbtc_treasury.address,
                                  timestamp_ms=1_700_000_500_000)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_both_assets_minted_at_genesis(self):
        self.assertEqual(self.chain.balance(self.treasury.address, "qsam"), QSAM_SUPPLY)
        self.assertEqual(self.chain.balance(self.qbtc_treasury.address, "qbtc"), QBTC_SUPPLY)

    def test_genesis_has_one_tx_per_asset(self):
        genesis = self.chain.blocks[0]["transactions"]
        self.assertEqual(len(genesis), len(ASSETS))
        self.assertEqual({tx["asset"] for tx in genesis}, set(ASSETS))

    def test_qbtc_transfer_rejected_by_mempool(self):
        tx = self.qbtc_treasury.make_tx(
            self.alice.address, 1_000_000, 1_000,
            self.chain.next_nonce(self.qbtc_treasury.address),
            int(time.time() * 1000), "selling it", asset="qbtc")
        ok, why = self.chain.add_to_mempool(tx)
        self.assertFalse(ok)
        self.assertIn("non-transferable", why)

    def test_qbtc_movement_rejected_by_block_validation(self):
        tx = self.qbtc_treasury.make_tx(
            self.alice.address, 1_000_000, 1_000,
            self.chain.next_nonce(self.qbtc_treasury.address),
            int(time.time() * 1000), "bypass", asset="qbtc")
        sneaky = chain_mod.mine_block(self.chain.head(), [tx], self.treasury.address,
                                      self.chain.config,
                                      timestamp_ms=int(time.time() * 1000))
        ok, errors = self.chain.validate_block(sneaky, self.chain.head())
        self.assertFalse(ok)
        self.assertTrue(any("non-transferable" in e for e in errors), errors)

    def test_qsam_still_transfers_while_qbtc_is_locked(self):
        tx = self.treasury.make_tx(self.alice.address, 5_000 * chain_mod.UNITS, 1_000,
                                   self.chain.next_nonce(self.treasury.address),
                                   int(time.time() * 1000), "normal", asset="qsam")
        ok, why = self.chain.add_to_mempool(tx)
        self.assertTrue(ok, why)
        self.chain.mine(self.treasury.address)
        self.assertEqual(self.chain.balance(self.alice.address, "qsam"), 5_000 * chain_mod.UNITS)
        self.assertEqual(self.chain.balance(self.alice.address, "qbtc"), 0)
        valid, errors = self.chain.validate()
        self.assertTrue(valid, errors)

    def test_unknown_asset_rejected(self):
        tx = self.treasury.make_tx(self.alice.address, 1_000, 1_000,
                                   self.chain.next_nonce(self.treasury.address),
                                   int(time.time() * 1000), "fake", asset="doge")
        ok, why = self.chain.add_to_mempool(tx)
        self.assertFalse(ok)
        self.assertIn("unknown asset", why)

    def test_cannot_spend_qbtc_balance_as_qsam(self):
        tx = self.qbtc_treasury.make_tx(self.alice.address, 1_000, 1_000,
                                        self.chain.next_nonce(self.qbtc_treasury.address),
                                        int(time.time() * 1000), "wrong asset", asset="qsam")
        ok, why = self.chain.add_to_mempool(tx)
        self.assertFalse(ok)
        self.assertIn("insufficient QSAM", why)

    def test_asset_supplies_are_independent(self):
        balances, _ = self.chain.state()
        self.assertEqual(sum(balances["qsam"].values()), QSAM_SUPPLY)
        self.assertEqual(sum(balances["qbtc"].values()), QBTC_SUPPLY)

    def test_inflating_qbtc_supply_fails_audit(self):
        self.chain.blocks[0]["transactions"][1]["amount"] += chain_mod.UNITS
        ok, errors = self.chain.validate()
        self.assertFalse(ok)
        self.assertTrue(any("QBTC" in e or "genesis amount" in e for e in errors), errors)


class ForkChoiceTests(unittest.TestCase):
    """Fork choice: most cumulative quantum work wins, then height, then hash."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.treasury = Wallet(name="tsam")
        self.other = Wallet(name="other")
        self.chain = Chain(self.tmp)
        self.chain.save_config(quantum_min_amplification=2.0, difficulty=0)
        self.chain.create_genesis(self.treasury.address, timestamp_ms=1_700_000_600_000)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _block_off(self, parent, miner=None, ts=1_700_000_700_000):
        return chain_mod.mine_block(parent, [], (miner or self.other).address,
                                    self.chain.config, timestamp_ms=ts)

    def test_cumulative_work_is_the_sum_of_every_block(self):
        self.chain.mine(self.treasury.address, timestamp_ms=1_700_000_650_000)
        expected = sum(b["header"]["quantum"]["amplification"] for b in self.chain.blocks)
        self.assertAlmostEqual(self.chain.cumulative_work(), expected, places=3)

    def test_unknown_parent_is_an_orphan_not_an_acceptance(self):
        ghost = {"header": {"height": 4}, "hash": "ab" * 32}
        block = self._block_off(ghost)
        result = self.chain.receive_block(block)
        self.assertEqual(result["status"], "orphan")
        self.assertFalse(result["relay"])

    def test_known_block_is_a_duplicate(self):
        self.chain.mine(self.treasury.address, timestamp_ms=1_700_000_651_000)
        result = self.chain.receive_block(self.chain.head())
        self.assertEqual(result["status"], "duplicate")

    def test_valid_extension_is_appended(self):
        height_before = self.chain.height()
        block = self._block_off(self.chain.head())
        result = self.chain.receive_block(block)
        self.assertEqual(result["status"], "appended")
        self.assertEqual(self.chain.height(), height_before + 1)
        self.assertEqual(self.chain.head()["hash"], block["hash"])

    def test_heavier_branch_wins_and_lighter_is_kept_as_side(self):
        self.chain.mine(self.treasury.address, timestamp_ms=1_700_000_652_000)
        genesis = self.chain.blocks[0]
        alt = self._block_off(genesis, ts=1_700_000_653_000)
        candidate = (self.chain.work_of([genesis, alt]), 1, alt["hash"])
        before = self.chain.tip_key()
        result = self.chain.receive_block(alt)
        if candidate > before:
            self.assertIn(result["status"], ("reorg", "appended"))
            self.assertEqual(self.chain.head()["hash"], alt["hash"])
        else:
            self.assertEqual(result["status"], "side")
            self.assertEqual(self.chain.head()["hash"], before[2])

    def test_block_with_a_broken_hash_is_refused(self):
        block = copy.deepcopy(self.chain.head())
        block["header"]["timestamp"] += 1
        result = self.chain.receive_block(block)
        self.assertEqual(result["status"], "rejected")
        self.assertIn("hash", result["detail"])

    def test_foreign_chain_id_is_refused(self):
        block = copy.deepcopy(self.chain.head())
        block["header"]["chain_id"] = "someone-elses-chain"
        block["hash"] = chain_mod.block_hash(block["header"])
        result = self.chain.receive_block(block)
        self.assertEqual(result["status"], "rejected")



class StaleTransactionTests(unittest.TestCase):
    """A reorg can make a pending tx impossible. That must never reach a block."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.chain = Chain(self.tmp)
        self.chain.save_config(quantum_min_amplification=2.0, difficulty=0)
        self.treasury = Wallet(name="treasury")
        self.alice = Wallet(name="alice")
        self.chain.create_genesis(self.treasury.address, timestamp_ms=1_800_000_000_000)
        self.tx = self.treasury.make_tx(self.alice.address, 5_000 * chain_mod.UNITS,
                                        1_000, 0, 1_800_000_000_001, "first")
        ok, why = self.chain.add_to_mempool(self.tx)
        self.assertTrue(ok, why)
        self.chain.mine(self.treasury.address)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_replaying_a_confirmed_tx_in_a_new_block_is_refused(self):
        block = chain_mod.mine_block(self.chain.head(), [self.tx],
                                    self.alice.address, self.chain.config,
                                    timestamp_ms=1_800_000_000_900)
        ok, errs = self.chain.validate_block(block, self.chain.head())
        self.assertFalse(ok, "a block re-including a confirmed tx must be invalid")
        self.assertTrue(any("nonce" in e for e in errs), errs)

    def test_confirmed_tx_cannot_re_enter_the_mempool(self):
        ok, why = self.chain.add_to_mempool(self.tx)
        self.assertFalse(ok)
        self.assertIn("confirmed", why)

    def test_next_nonce_advances_after_confirmation(self):
        self.assertEqual(self.chain.next_nonce(self.treasury.address), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
