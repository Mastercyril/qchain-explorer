"""
The 13th Chamber chain: a multi-asset ledger with Proof-of-Quantum-Work blocks.

Two assets live on this chain
-----------------------------
QSAM  transferable. 1,000,000,000 fixed. The public, renounced asset that also
      trades on Solana as 48YZxAUXFcEG14kEWHyBBaEx1gabprkXxQsz2ViuPZPN.
QBTC  non-transferable. 21,000,000 fixed. Moves exactly once, from the genesis
      transaction to the QBTC treasury, and can never move again. It is a
      register of custody, not a spendable coin: any attempt to transfer it is
      rejected by the mempool, by block validation and by the full audit.

Neither asset has a mint path. Supply is asserted against config on every audit.
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import quantum
from wallet import canonical, tx_hash, verify_tx

UNITS = 1_000_000                      # 6 decimals, same shape as the SPL tokens

QSAM_SUPPLY = 1_000_000_000 * UNITS
QBTC_SUPPLY = 21_000_000 * UNITS

DEFAULT_ASSET = "qsam"

ASSETS: Dict[str, Dict[str, Any]] = {
    "qsam": {
        "name": "QSAM",
        "symbol": "QSAM",
        "full_name": "Quantum System Access Module",
        "supply": QSAM_SUPPLY,
        "decimals": 6,
        "transferable": True,
        "note": "Transferable. Fixed supply, no mint authority.",
    },
    "qbtc": {
        "name": "QBTC",
        "symbol": "QBTC",
        "full_name": "Quantum Bitcoin",
        "supply": QBTC_SUPPLY,
        "decimals": 6,
        "transferable": False,
        "note": "NOT FOR SALE. Non-transferable register of custody.",
    },
}

DEFAULT_CONFIG: Dict[str, Any] = {
    "chain_id": "13th-chamber-powq-1",
    "quantum_min_amplification": 12.5,   # whitepaper s8.2 consensus average
    "difficulty": 1,                     # leading hex zeros on the block hash
    "min_fee": 1_000,                    # 0.001 in the transaction's own asset
    "n_qubits": quantum.N_QUBITS,
    "genesis_note": "13th Chamber LLC genesis - fixed supply, no mint path",
}

DATA_DIR = "data"
CHAIN_FILE = os.path.join(DATA_DIR, "chain.jsonl")


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def fmt(units: int) -> str:
    return f"{units / UNITS:,.6f}"


def asset_of(tx: Dict[str, Any]) -> str:
    return tx.get("asset", DEFAULT_ASSET)


def asset_spec(asset: str) -> Dict[str, Any]:
    if asset not in ASSETS:
        raise ValueError(f"unknown asset '{asset}'")
    return ASSETS[asset]


def total_supply() -> int:
    return sum(spec["supply"] for spec in ASSETS.values())


def merkle_root(hashes: List[str]) -> str:
    """RFC6962-style Merkle tree: leaf=0x00||h, node=0x01||l||r."""
    if not hashes:
        return hashlib.sha256(b"empty").hexdigest()
    level = [hashlib.sha256(b"\x00" + bytes.fromhex(h)).digest() for h in hashes]
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        level = [
            hashlib.sha256(b"\x01" + level[i] + level[i + 1]).digest()
            for i in range(0, len(level), 2)
        ]
    return level[0].hex()


def block_hash(header: Dict[str, Any]) -> str:
    return hashlib.sha256(canonical(header)).hexdigest()


def me(tx: Dict[str, Any]) -> str:
    return tx_hash(tx)


# --------------------------------------------------------------------------
# mining
# --------------------------------------------------------------------------

def mine_block(prev_block: Optional[Dict[str, Any]], txs: List[Dict[str, Any]],
               miner: str, config: Dict[str, Any],
               timestamp_ms: Optional[int] = None,
               max_nonce: int = 5_000_000,
               verbose: bool = False) -> Dict[str, Any]:
    """
    Search nonces until the challenge circuit amplifies above the network
    threshold and the resulting block hash meets the classical difficulty.
    """
    height = 0 if prev_block is None else prev_block["header"]["height"] + 1
    prev_hash = "0" * 64 if prev_block is None else prev_block["hash"]
    ts = timestamp_ms or int(time.time() * 1000)
    root = merkle_root([me(tx) for tx in txs])
    need_amp = float(config["quantum_min_amplification"])
    zeroes = "0" * int(config["difficulty"])
    started = time.time()

    for nonce in range(max_nonce):
        challenge = quantum.make_challenge(prev_hash, root, miner, ts, nonce)
        work = quantum.work_result(challenge)
        if work["amplification"] < need_amp:
            continue
        header = {
            "v": 1,
            "chain_id": config["chain_id"],
            "height": height,
            "prev_hash": prev_hash,
            "merkle_root": root,
            "timestamp": ts,
            "miner": miner,
            "nonce": nonce,
            "difficulty": int(config["difficulty"]),
            "tx_count": len(txs),
            "quantum": {
                "n_qubits": work["n_qubits"],
                "gate_count": work["gate_count"],
                "challenge": challenge.hex(),
                "target_index": work["target_index"],
                "target_bits": work["target_bits"],
                "concentration": work["concentration"],
                "baseline": work["baseline"],
                "amplification": work["amplification"],
                "state_fingerprint": work["state_fingerprint"],
            },
        }
        digest = block_hash(header)
        if not digest.startswith(zeroes):
            continue
        block = {
            "header": header,
            "transactions": txs,
            "hash": digest,
            "mined_ms": int((time.time() - started) * 1000),
            "nonces_tried": nonce + 1,
        }
        if verbose:
            print(f"    nonce {nonce} ({nonce+1} tries), {work['amplification']:.2f}x, "
                  f"{block['mined_ms']}ms")
        return block

    raise RuntimeError("nonce budget exhausted - raise max_nonce or lower difficulty")


# --------------------------------------------------------------------------
# chain
# --------------------------------------------------------------------------

class Chain:
    def __init__(self, data_dir: str = DATA_DIR):
        self.data_dir = data_dir
        self.chain_file = os.path.join(data_dir, "chain.jsonl")
        self.mempool_file = os.path.join(data_dir, "mempool.json")
        self.config_file = os.path.join(data_dir, "config.json")
        os.makedirs(data_dir, exist_ok=True)
        self.config = self._load_config()
        self.blocks: List[Dict[str, Any]] = self._load_blocks()
        self._state_cache: Optional[Tuple[Dict[str, Dict[str, int]], Dict[str, int]]] = None
        # reentrant: fork choice, adoption and mining all run under this
        self.lock = threading.RLock()
        self._known: Dict[str, Dict[str, Any]] = {b["hash"]: b for b in self.blocks}
        # blocks already proven valid against their parent; adopt() trusts these
        self._validated: set = set()

    # -- config ------------------------------------------------------------
    def _load_config(self) -> Dict[str, Any]:
        if os.path.exists(self.config_file):
            with open(self.config_file) as fh:
                cfg = json.load(fh)
            merged = dict(DEFAULT_CONFIG)
            merged.update(cfg)
            return merged
        with open(self.config_file, "w") as fh:
            json.dump(DEFAULT_CONFIG, fh, indent=2)
        return dict(DEFAULT_CONFIG)

    def save_config(self, **changes: Any) -> Dict[str, Any]:
        self.config.update({k: v for k, v in changes.items() if v is not None})
        with open(self.config_file, "w") as fh:
            json.dump(self.config, fh, indent=2)
        return self.config

    # -- persistence -------------------------------------------------------
    def _load_blocks(self) -> List[Dict[str, Any]]:
        if not os.path.exists(self.chain_file):
            return []
        out = []
        with open(self.chain_file) as fh:
            for line in fh:
                line = line.strip()
                if line:
                    out.append(json.loads(line))
        return out

    def _append(self, block: Dict[str, Any]) -> None:
        with open(self.chain_file, "a") as fh:
            fh.write(json.dumps(block, sort_keys=True) + "\n")
        self.blocks.append(block)
        self._known[block["hash"]] = block
        self._state_cache = None

    # -- mempool -----------------------------------------------------------
    def mempool(self) -> List[Dict[str, Any]]:
        with self.lock:
            try:
                with open(self.mempool_file) as fh:
                    data = json.load(fh)
                return data if isinstance(data, list) else []
            except Exception:
                return []

    def save_mempool(self, txs: List[Dict[str, Any]]) -> None:
        """Atomic replace so a reader never sees a half written file."""
        with self.lock:
            tmp = self.mempool_file + ".tmp"
            with open(tmp, "w") as fh:
                json.dump(txs, fh, indent=2)
            os.replace(tmp, self.mempool_file)

    def add_to_mempool(self, tx: Dict[str, Any]) -> Tuple[bool, str]:
        with self.lock:
            return self._add_to_mempool_locked(tx)

    def _add_to_mempool_locked(self, tx: Dict[str, Any]) -> Tuple[bool, str]:
        ok, why = verify_tx(tx)
        if not ok:
            return False, why

        asset = asset_of(tx)
        if asset not in ASSETS:
            return False, f"unknown asset '{asset}'"
        spec = ASSETS[asset]
        if not spec["transferable"]:
            return False, f"{spec['symbol']} is non-transferable (not for sale)"

        pool = self.mempool()
        if any(me(t) == me(tx) for t in pool):
            return False, "already in mempool"
        for b in self.blocks:
            for t in b["transactions"]:
                if me(t) == me(tx):
                    return False, "already confirmed"

        balances, nonces = self.state()
        held = balances.get(asset, {}).get(tx["from"], 0)
        pending = sum(t["amount"] + t["fee"] for t in pool
                      if t["from"] == tx["from"] and asset_of(t) == asset)
        if held - pending < tx["amount"] + tx["fee"]:
            return False, (f"insufficient {spec['symbol']}: have {fmt(held)}, "
                           f"pending {fmt(pending)}")
        expected = nonces.get(tx["from"], 0) + len([t for t in pool if t["from"] == tx["from"]])
        if int(tx["nonce"]) != expected:
            return False, f"bad nonce: expected {expected}, got {tx['nonce']}"
        if int(tx["fee"]) < int(self.config["min_fee"]):
            return False, f"fee below minimum ({fmt(self.config['min_fee'])})"
        pool.append(tx)
        self.save_mempool(pool)
        return True, "accepted"

    # -- state -------------------------------------------------------------
    def _replay(self, blocks: List[Dict[str, Any]]
                ) -> Tuple[Dict[str, Dict[str, int]], Dict[str, int]]:
        """Replay any block list into per-asset balances and per-address nonces."""
        balances: Dict[str, Dict[str, int]] = {a: {} for a in ASSETS}
        nonces: Dict[str, int] = {}
        for block in blocks:
            for tx in block["transactions"]:
                asset = asset_of(tx)
                if asset not in balances:
                    balances[asset] = {}
                ledger = balances[asset]
                amount, fee = int(tx["amount"]), int(tx["fee"])
                sender = tx["from"]
                if sender == "genesis":
                    ledger[tx["to"]] = ledger.get(tx["to"], 0) + amount
                    continue
                ledger[sender] = ledger.get(sender, 0) - amount - fee
                ledger[tx["to"]] = ledger.get(tx["to"], 0) + amount
                nonces[sender] = max(nonces.get(sender, 0), int(tx["nonce"]) + 1)
            miner = block["header"]["miner"]
            for tx in block["transactions"]:
                if tx["from"] == "genesis" or not int(tx["fee"]):
                    continue
                ledger = balances[asset_of(tx)]
                ledger[miner] = ledger.get(miner, 0) + int(tx["fee"])
        return balances, nonces

    def state(self) -> Tuple[Dict[str, Dict[str, int]], Dict[str, int]]:
        """Balances and nonces for the active chain."""
        if self._state_cache is not None:
            return self._state_cache
        self._state_cache = self._replay(self.blocks)
        return self._state_cache

    def state_at(self, marker: Optional[Dict[str, Any]]
                 ) -> Tuple[Dict[str, Dict[str, int]], Dict[str, int]]:
        """Balances and nonces as of a given block, for validating branches."""
        if marker is None:
            return ({a: {} for a in ASSETS}, {})
        if self.blocks and marker["hash"] == self.blocks[-1]["hash"]:
            return self.state()
        path = self._path_to_genesis(marker["hash"])
        if path is None:
            return self.state()
        return self._replay(path)

    def balance(self, address: str, asset: str = DEFAULT_ASSET) -> int:
        return self.state()[0].get(asset, {}).get(address, 0)

    def balances_of(self, address: str) -> Dict[str, int]:
        balances, _ = self.state()
        return {a: balances.get(a, {}).get(address, 0) for a in ASSETS}

    def next_nonce(self, address: str) -> int:
        base = self.state()[1].get(address, 0)
        return base + len([t for t in self.mempool() if t["from"] == address])

    # -- block production --------------------------------------------------
    def create_genesis(self, treasury_address: str,
                       qbtc_address: Optional[str] = None,
                       timestamp_ms: Optional[int] = None) -> Dict[str, Any]:
        """Mint each asset exactly once. This is the only creation event."""
        if self.blocks:
            raise RuntimeError("chain already has a genesis block")
        ts = timestamp_ms or int(time.time() * 1000)
        txs = []
        for asset, spec in ASSETS.items():
            dest = treasury_address
            if asset == "qbtc" and qbtc_address:
                dest = qbtc_address
            txs.append({
                "v": 1,
                "type": "genesis",
                "asset": asset,
                "from": "genesis",
                "to": dest,
                "amount": spec["supply"],
                "fee": 0,
                "nonce": 0,
                "timestamp": ts,
                "memo": f"{spec['full_name']} genesis - {spec['note']}",
                "pubkey": "",
                "signature": "",
            })
        block = mine_block(None, txs, treasury_address, self.config, timestamp_ms=ts)
        self._append(block)
        return block

    def mine(self, miner: str, max_txs: int = 50,
             timestamp_ms: Optional[int] = None,
             verbose: bool = False) -> Dict[str, Any]:
        with self.lock:
            return self._mine_locked(miner, max_txs, timestamp_ms, verbose)

    def _mine_locked(self, miner: str, max_txs: int = 50,
                     timestamp_ms: Optional[int] = None,
                     verbose: bool = False) -> Dict[str, Any]:
        if not self.blocks:
            raise RuntimeError("no genesis block yet")
        pool = self.mempool()[:max_txs]
        prev = self.blocks[-1]
        block = mine_block(prev, pool, miner, self.config,
                           timestamp_ms=timestamp_ms, verbose=verbose)
        ok, errors = self.validate_block(block, prev)
        if not ok:
            used = {me(t) for t in pool}
            self.save_mempool([t for t in self.mempool() if me(t) not in used])
            raise RuntimeError(f"mined an invalid block, dropped those txs: {errors[0]}")
        self._append(block)
        used = {me(t) for t in pool}
        self.save_mempool([t for t in self.mempool() if me(t) not in used])
        return block

    # -- validation --------------------------------------------------------
    def validate_block(self, block: Dict[str, Any],
                       prev: Optional[Dict[str, Any]]) -> Tuple[bool, List[str]]:
        errors: List[str] = []
        h = block["header"]

        height = 0 if prev is None else prev["header"]["height"] + 1
        prev_hash = "0" * 64 if prev is None else prev["hash"]
        if h["height"] != height:
            errors.append(f"height {h['height']} != expected {height}")
        if h["prev_hash"] != prev_hash:
            errors.append("prev_hash does not match the previous block")

        expected_hash = block_hash(h)
        if expected_hash != block["hash"]:
            errors.append("block hash does not match its header")
        if not expected_hash.startswith("0" * int(self.config["difficulty"])):
            errors.append("block hash does not meet difficulty")
        if h.get("chain_id") != self.config["chain_id"]:
            errors.append("wrong chain id")

        txs = block["transactions"]
        if h["tx_count"] != len(txs):
            errors.append("tx_count mismatch")
        if merkle_root([me(t) for t in txs]) != h["merkle_root"]:
            errors.append("merkle root does not match the transactions")

        for i, tx in enumerate(txs):
            asset = asset_of(tx)
            if asset not in ASSETS:
                errors.append(f"tx {i}: unknown asset '{asset}'")
                continue
            spec = ASSETS[asset]
            if tx.get("from") == "genesis":
                if h["height"] != 0:
                    errors.append("genesis transaction outside block 0")
                elif int(tx["amount"]) != spec["supply"]:
                    errors.append(f"genesis amount for {asset} is not the full supply")
                continue
            if not spec["transferable"]:
                errors.append(f"tx {i}: {spec['symbol']} is non-transferable but was moved")
            ok, why = verify_tx(tx)
            if not ok:
                errors.append(f"tx {i} ({me(tx)[:10]}): {why}")

        # economic rules: replay this block against the state it builds on, so a
        # stale or duplicated transaction can never be mined or accepted
        base_bal, base_nonce = self.state_at(prev)
        scratch_bal = {a: dict(v) for a, v in base_bal.items()}
        scratch_nonce = dict(base_nonce)
        for i, tx in enumerate(txs):
            if tx.get("from") == "genesis":
                continue
            asset = asset_of(tx)
            ledger = scratch_bal.setdefault(asset, {})
            sender = tx["from"]
            amount, fee = int(tx["amount"]), int(tx["fee"])
            expected = scratch_nonce.get(sender, 0)
            if int(tx["nonce"]) != expected:
                errors.append(f"tx {i}: nonce {tx['nonce']} != expected {expected}")
            if ledger.get(sender, 0) < amount + fee:
                errors.append(f"tx {i}: {sender[:12]} cannot afford "
                              f"{fmt(amount + fee)} {asset.upper()}")
            ledger[sender] = ledger.get(sender, 0) - amount - fee
            ledger[tx["to"]] = ledger.get(tx["to"], 0) + amount
            scratch_nonce[sender] = int(tx["nonce"]) + 1
        miner_addr = h["miner"]
        for tx in txs:
            if tx.get("from") == "genesis" or not int(tx["fee"]):
                continue
            scratch_bal.setdefault(asset_of(tx), {})
            scratch_bal[asset_of(tx)][miner_addr] = (
                scratch_bal[asset_of(tx)].get(miner_addr, 0) + int(tx["fee"]))

        q = h["quantum"]
        challenge = quantum.make_challenge(h["prev_hash"], h["merkle_root"],
                                           h["miner"], h["timestamp"], h["nonce"])
        if q.get("challenge") != challenge.hex():
            errors.append("challenge does not match the block header")
        else:
            ok, why = quantum.verify_work(challenge, q)
            if not ok:
                errors.append(f"quantum work invalid: {why}")
            if float(q["amplification"]) < float(self.config["quantum_min_amplification"]):
                errors.append(f"amplification {q['amplification']:.2f}x below "
                              f"network threshold {self.config['quantum_min_amplification']}x")
        return (not errors), errors

    def validate(self) -> Tuple[bool, List[str]]:
        """Full audit: structure, signatures, economics and per-asset supply."""
        errors: List[str] = []
        if not self.blocks:
            return False, ["chain is empty"]

        prev = None
        for block in self.blocks:
            ok, errs = self.validate_block(block, prev)
            errors.extend(errs)
            prev = block

        balances: Dict[str, Dict[str, int]] = {a: {} for a in ASSETS}
        nonces: Dict[str, int] = {}
        for block in self.blocks:
            for tx in block["transactions"]:
                asset = asset_of(tx)
                ledger = balances.setdefault(asset, {})
                if tx.get("from") == "genesis":
                    ledger[tx["to"]] = ledger.get(tx["to"], 0) + int(tx["amount"])
                    continue
                sender = tx["from"]
                need = int(tx["amount"]) + int(tx["fee"])
                if ledger.get(sender, 0) < need:
                    errors.append(
                        f"block {block['header']['height']}: {sender[:12]} overspends {asset} "
                        f"(has {fmt(ledger.get(sender,0))}, needs {fmt(need)})")
                if int(tx["nonce"]) != nonces.get(sender, 0):
                    errors.append(
                        f"block {block['header']['height']}: {sender[:12]} nonce "
                        f"{tx['nonce']} != expected {nonces.get(sender,0)}")
                ledger[sender] = ledger.get(sender, 0) - need
                ledger[tx["to"]] = ledger.get(tx["to"], 0) + int(tx["amount"])
                nonces[sender] = int(tx["nonce"]) + 1
            miner = block["header"]["miner"]
            for tx in block["transactions"]:
                if tx.get("from") == "genesis" or not int(tx["fee"]):
                    continue
                ledger = balances.setdefault(asset_of(tx), {})
                ledger[miner] = ledger.get(miner, 0) + int(tx["fee"])

        for asset, spec in ASSETS.items():
            total = sum(balances.get(asset, {}).values())
            if total != spec["supply"]:
                errors.append(f"{spec['symbol']} supply drifted: {fmt(total)} != {fmt(spec['supply'])}")

        return (not errors), errors

    # -- views -------------------------------------------------------------
    def head(self) -> Optional[Dict[str, Any]]:
        return self.blocks[-1] if self.blocks else None

    def height(self) -> int:
        return -1 if not self.blocks else self.blocks[-1]["header"]["height"]

    def summary(self) -> Dict[str, Any]:
        balances, _ = self.state()
        assets = []
        for asset, spec in ASSETS.items():
            ledger = balances.get(asset, {})
            top = sorted(ledger.items(), key=lambda kv: kv[1], reverse=True)[:5]
            assets.append({
                "asset": asset,
                "symbol": spec["symbol"],
                "full_name": spec["full_name"],
                "supply": fmt(spec["supply"]),
                "decimals": spec["decimals"],
                "transferable": spec["transferable"],
                "note": spec["note"],
                "holders": len([1 for v in ledger.values() if v > 0]),
                "top_holders": [{"address": a, "balance": fmt(b)} for a, b in top if b > 0],
            })
        qsam_ledger = balances.get("qsam", {})
        return {
            "chain_id": self.config["chain_id"],
            "height": self.height(),
            "blocks": len(self.blocks),
            "transactions": sum(len(b["transactions"]) for b in self.blocks),
            "mempool": len(self.mempool()),
            "assets": assets,
            "holders": len([1 for v in qsam_ledger.values() if v > 0]),
            "head_hash": self.head()["hash"] if self.blocks else None,
            "head_time": self.head()["header"]["timestamp"] if self.blocks else None,
            "quantum_threshold": self.config["quantum_min_amplification"],
            "difficulty": self.config["difficulty"],
            "avg_amplification": self._avg_amp(),
            "cumulative_work": self.cumulative_work(),
            "top_holders": [{"address": a, "balance": fmt(b)}
                            for a, b in sorted(qsam_ledger.items(),
                                               key=lambda kv: kv[1], reverse=True)[:5] if b > 0],
        }

    def _avg_amp(self) -> float:
        amps = [b["header"]["quantum"]["amplification"] for b in self.blocks]
        return round(sum(amps) / len(amps), 2) if amps else 0.0

    # ------------------------------------------------------------------
    # peer-to-peer: cumulative quantum work, side branches, reorgs
    # ------------------------------------------------------------------
    def work_of(self, blocks: List[Dict[str, Any]]) -> float:
        return sum(float(b["header"]["quantum"]["amplification"]) for b in blocks)

    def cumulative_work(self) -> float:
        return round(self.work_of(self.blocks), 4)

    def tip_key(self) -> Tuple[float, int, str]:
        """Fork choice key: most cumulative quantum work wins, then height, then hash."""
        return (self.cumulative_work(),
                self.height(),
                self.head()["hash"] if self.blocks else "")

    def blocks_from(self, height: int) -> List[Dict[str, Any]]:
        return [b for b in self.blocks if b["header"]["height"] >= height]

    def known_count(self) -> int:
        return len(self._known)

    def _path_to_genesis(self, head_hash: str) -> Optional[List[Dict[str, Any]]]:
        """Walk parents back to genesis. Returns an ordered chain or None."""
        out: List[Dict[str, Any]] = []
        cur = self._known.get(head_hash)
        guard = 0
        while cur is not None:
            out.append(cur)
            if cur["header"]["height"] == 0:
                break
            cur = self._known.get(cur["header"]["prev_hash"])
            guard += 1
            if guard > 100_000:
                return None
        if not out or out[-1]["header"]["height"] != 0:
            return None
        out.reverse()
        for i, b in enumerate(out):
            if b["header"]["height"] != i:
                return None
            if i and b["header"]["prev_hash"] != out[i - 1]["hash"]:
                return None
        return out

    def receive_block(self, block: Any) -> Dict[str, Any]:
        """
        Take a block from a peer and decide what it means:
          appended  extends our tip
          reorg     a heavier branch replaced ours
          side      valid but lighter, kept for later
          duplicate / orphan / rejected
        """
        with self.lock:
            if not isinstance(block, dict) or "header" not in block or "hash" not in block:
                return {"status": "rejected", "detail": "malformed block", "relay": False}
            if block_hash(block["header"]) != block["hash"]:
                return {"status": "rejected", "detail": "block hash does not match its header",
                        "relay": False}
            if block["hash"] in self._known:
                return {"status": "duplicate", "detail": "already known", "relay": False}
            header = block["header"]
            if header.get("chain_id") != self.config["chain_id"]:
                return {"status": "rejected", "detail": "wrong chain id", "relay": False}

            if header["height"] == 0:
                if self.blocks:
                    return {"status": "duplicate", "detail": "already have a genesis block",
                            "relay": False}
                ok, errs = self.validate_block(block, None)
                if not ok:
                    return {"status": "rejected", "detail": "; ".join(errs), "relay": False}
                self._known[block["hash"]] = block
                self.adopt([block])
                return {"status": "appended", "detail": "adopted genesis", "relay": False}

            prev = self._known.get(header["prev_hash"])
            if prev is None:
                return {"status": "orphan", "detail": "unknown parent, need sync", "relay": False}

            ok, errs = self.validate_block(block, prev)
            if not ok:
                return {"status": "rejected", "detail": "; ".join(errs), "relay": False}

            self._known[block["hash"]] = block
            self._validated.add(block["hash"])
            path = self._path_to_genesis(block["hash"])
            if path is None:
                return {"status": "orphan", "detail": "cannot trace to genesis", "relay": False}

            old_head = self.head()["hash"] if self.blocks else None
            candidate = (self.work_of(path), path[-1]["header"]["height"], path[-1]["hash"])
            if candidate > self.tip_key():
                extending = header["prev_hash"] == old_head
                self.adopt(path)
                return {
                    "status": "appended" if extending else "reorg",
                    "detail": f"tip {path[-1]['hash'][:12]} height {path[-1]['header']['height']}",
                    "relay": True,
                }
            return {"status": "side",
                    "detail": "valid but our tip carries at least as much work",
                    "relay": True}

    def adopt(self, blocks: List[Dict[str, Any]]) -> None:
        """Replace the active chain with a branch that reaches genesis."""
        with self.lock:
            if not blocks:
                raise ValueError("cannot adopt an empty chain")
            prev = None
            for b in blocks:
                if b["hash"] not in self._validated:
                    ok, errs = self.validate_block(b, prev)
                    if not ok:
                        raise ValueError("refusing to adopt invalid branch: " + "; ".join(errs))
                    self._validated.add(b["hash"])
                prev = b
            new_hashes = {b["hash"] for b in blocks}
            orphaned = [tx for b in self.blocks if b["hash"] not in new_hashes
                        for tx in b["transactions"]]
            with open(self.chain_file, "w") as fh:
                for b in blocks:
                    fh.write(json.dumps(b, sort_keys=True) + "\n")
            self.blocks = list(blocks)
            self._state_cache = None
            for b in blocks:
                self._known[b["hash"]] = b
            self._requeue(orphaned)
            self._sanitize_mempool()

    def _sanitize_mempool(self) -> None:
        """Drop pending transactions the adopted chain has made impossible.

        After a reorg a tx can be stale in two ways: it is already confirmed, or
        its nonce no longer lines up with the sender's account. Either way it
        must leave the pool or it will poison the next block.
        """
        pool = self.mempool()
        if not pool:
            return
        balances, nonces = self.state()
        confirmed = {me(t) for b in self.blocks for t in b["transactions"]}
        keep: List[Dict[str, Any]] = []
        spent: Dict[tuple, int] = {}
        for tx in pool:
            if me(tx) in confirmed:
                continue
            sender, asset = tx["from"], asset_of(tx)
            held = balances.get(asset, {}).get(sender, 0)
            used = spent.get((sender, asset), 0)
            expected = nonces.get(sender, 0) + len([t for t in keep if t["from"] == sender])
            if int(tx["nonce"]) != expected:
                continue
            if held - used < int(tx["amount"]) + int(tx["fee"]):
                continue
            spent[(sender, asset)] = used + int(tx["amount"]) + int(tx["fee"])
            keep.append(tx)
        if len(keep) != len(pool):
            self.save_mempool(keep)

    def _requeue(self, orphaned: List[Dict[str, Any]]) -> None:
        """Transactions from orphaned blocks go back to the mempool, best effort."""
        confirmed = {me(tx) for b in self.blocks for tx in b["transactions"]}
        pool = self.mempool()
        for tx in orphaned:
            if tx.get("from") == "genesis":
                continue
            txh = me(tx)
            if txh in confirmed or any(me(t) == txh for t in pool):
                continue
            try:
                if verify_tx(tx)[0]:
                    pool.append(tx)
                    self.save_mempool(pool)
            except Exception:
                continue
